//
//  NodeBille.m
//  
//
//  Created by Mos on 19/10/2015.
//
//

#import <Foundation/Foundation.h>

#import "NodePalette2L.h"

@implementation NodePalette2L

- (instancetype) init {
    // note that [super init] will call the SpaceshipNode's init method
    if (self = [super init]) {
        NSLog(@"A new NodePalette2R was just init'ed.");
        self = (NodePalette2L*) [[SKSpriteNode alloc]initWithImageNamed:@"NodePalette2L"];
        self.name =@"NodePalette2L";
    }
    return self;
}

@end
