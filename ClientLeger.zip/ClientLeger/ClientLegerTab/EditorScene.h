//
//  EditorScene.m
//  ClientLeger_
//
//  Classe qui contient la logique de l'edition
//
//  Created by Mouhamadou Oumar on 18/10/2015.
//  Copyright (c) 2015 Mos. All rights reserved.



#import <SpriteKit/SpriteKit.h>
#import "VisitorXML.h"


@interface EditorScene : SKScene<UIAlertViewDelegate>

@property CGMutablePathRef pathToDraw;
@property SKShapeNode *lineNode;


+ (instancetype)sceneWithSize:(CGSize)size withFile:(DDXMLDocument*)doc;
- (instancetype)initWithSize:(CGSize)size withFile:(DDXMLDocument*)doc;


@end
