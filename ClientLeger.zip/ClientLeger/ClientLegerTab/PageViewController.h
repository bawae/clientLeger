//
//  PageViewController.h
//  ClientLegerTab
//
//  Created by Mos on 26/10/2015.
//  Copyright (c) 2015 Mos. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PageViewController : UIPageViewController


@end

