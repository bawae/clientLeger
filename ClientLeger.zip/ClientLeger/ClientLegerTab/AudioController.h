//
//  AudioController.h
//  ATBasicSounds
//
//  Created by Audrey M Tam on 22/03/2014.
//  Modified by Mouhamadou Oumar Sall
//  Copyright (c) 2014 Ray Wenderlich. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AudioController : NSObject

- (instancetype)init;
- (void)playBackgroundMusic;
- (void)playSystemSound;
- (void)stopBackgroundMusic;
@end
