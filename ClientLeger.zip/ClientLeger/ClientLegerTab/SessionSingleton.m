//
//  SessionSingleton.m
//  ClientLegerTab
//
//  Singleton qui gere la session d'un utilisateur
//  Created by Mouhamadou Oumar Sall on 21/11/2015.
//  Copyright (c) 2015 Mos. All rights reserved.
//

#import "SessionSingleton.h"

@implementation SessionSingleton

static SessionSingleton *sharedSessionSingleton = nil;    // static instance variable
static dispatch_once_t pred;


/*!
 * @discussion Methode qui retourne l'instance du MapSingleton
 *
 * @return MapSingleton
 */
+ (SessionSingleton *)sharedInstance {
    if (sharedSessionSingleton == nil) {
        dispatch_once(&pred, ^{
            sharedSessionSingleton = [[super allocWithZone:NULL] init];
        });
        sharedSessionSingleton->userName = nil;
        sharedSessionSingleton->userPassword = nil;
        sharedSessionSingleton->userEmail = nil;
        sharedSessionSingleton->userPicProfile = nil;
        sharedSessionSingleton->nom = @"Guest";
        sharedSessionSingleton->prenom = @"Guest";
        sharedSessionSingleton->tempsJeu = @"0mn0s";
        sharedSessionSingleton->pgagne = @"0";
        sharedSessionSingleton->pperdue = @"0";
        sharedSessionSingleton->highscore = @"0";
    
    }
    return sharedSessionSingleton;
}



- (void)setUserName:(NSString*) name {
    userName = name;
}
- (void)setUserEmail:(NSString*) email {
    userEmail = email;
}
- (void)setUserPassword:(NSString*)password {
    userPassword =password;
}

- (void)setUserPicure:(UIImage*)picture {
    userPicProfile = picture;
}

- (NSString*)getUsername {
    return userName;
}

- (NSString*)getUserEmail {
    return userEmail;
}

- (UIImage*)getUserPicture{
    return userPicProfile;
}
@end


