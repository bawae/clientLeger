//
//  MapSingleton.h
//  ClientLegerTab
//
//  Singleton qui permet de determiner l'etat de la carte en cours d'edition
//  ainsi que la carte en cours de chargement
//  Created by Mouhamadou Oumar Sall on 21/11/2015.
//  Copyright (c) 2015 Mos. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DDXML.h"
/*
 NSString * const PROP = @"Propriétaire : ";
 NSString * const DIFF = @"Difficulté : ";
 NSString * const PBC = @"Points Butoir Circulaire : ";
 NSString * const PBT = @"Points Butoir Triangulaire : ";
 NSString * const PPG = @"Points pour gagner : ";
 NSString * const PB = @"Points bille : ";
 NSString * const PC = @"Points cible : ";
 
 */
@interface MapSingleton : NSObject {
    NSString* cardTitle;
    NSString* cardUser;
    NSString* cardId;
    float pbc;
    NSInteger pbt;
    NSInteger ppg;
    NSInteger pb;
    NSInteger pc;
    NSInteger cardDifficulty;
}

+ (MapSingleton *)sharedInstance;
- (void)setCardTitle:(NSString*)t;
- (void)setCardUser:(NSString*)u;
- (void)setCardId:(NSString*)i;
- (void)setCardpbcirculaire:(NSInteger)p;
- (void)setCardpbtriangulaire:(NSInteger)p;
- (void)setCardpgagner:(NSInteger)p;
- (void)setCardpbille:(NSInteger)p;
- (void)setCardpcible:(NSInteger)p;
- (void)setCardDifficulty:(NSInteger)d;


- (NSString*)getCardTitle;
- (NSString*)getCardUser;
- (NSString*)getCardId;
- (NSInteger)getCardpbcirculaire;
- (NSInteger)getCardpbtriangulaire;
- (NSInteger)getCardpgagner;
- (NSInteger)getCardpbille;
- (NSInteger)getCardpcible;
- (NSInteger)getCardDifficulty;

@end
