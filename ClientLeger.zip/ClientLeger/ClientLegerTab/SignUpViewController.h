//
//  SignUpViewController.h
//  ClientLegerTab
//
//  Created by Mos on 26/11/2015.
//  Copyright (c) 2015 Mos. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SignUpViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *inscrireButton;
@property (weak, nonatomic) IBOutlet UIButton *annulerButton;
@property (weak, nonatomic) IBOutlet UISwitch *visibiltySwitch;
@property (weak, nonatomic) IBOutlet UILabel *VisibilityLabel;
@property (weak, nonatomic) IBOutlet UITextField *prenomField;
@property (weak, nonatomic) IBOutlet UITextField *nomField;

@end

