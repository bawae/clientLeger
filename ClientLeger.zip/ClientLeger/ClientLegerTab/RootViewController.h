//
//  RootViewController.h
//  ClientLeger_
//
//  Classe qui contient la logique de l'edition
//
//  Created by Mouhamadou Oumar on 18/10/2015.
//  InspiredBy com.TheAppGuruz. All rights reserved.

#import <UIKit/UIKit.h>
#import "PageContentViewController.h"

@interface RootViewController : UIViewController
<UIPageViewControllerDataSource>

@property (nonatomic,strong) UIPageViewController *PageViewController;
@property (nonatomic,strong) NSArray *arrayInstruction;
@property (nonatomic,strong) NSArray *arrayGifUrl;

- (PageContentViewController *)viewControllerAtIndex:(NSUInteger)index;

- (IBAction)btnStartAgain:(id)sender;

@end
