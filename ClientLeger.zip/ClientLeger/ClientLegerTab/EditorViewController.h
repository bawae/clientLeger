//
//  EditorViewController.h
//  ClientLeger_
//
//  Controlleur et vue du mode edition
//
//  Created by Mouhamadou Oumar on 18/10/2015.
//  Copyright (c) 2015 mos. All rights reserved.
//


#import <UIKit/UIKit.h>
#import <SpriteKit/SpriteKit.h>
#import "AudioController.h"

@interface EditorViewController : UIViewController

@property (strong, nonatomic) AudioController *audioController;

@end
