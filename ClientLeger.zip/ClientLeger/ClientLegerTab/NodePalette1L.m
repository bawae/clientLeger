//
//  NodeBille.m
//  
//
//  Created by Mos on 19/10/2015.
//
//

#import <Foundation/Foundation.h>

#import "NodePalette1L.h"
#import "Utility.h"


@implementation NodePalette1L

- (instancetype) init {
    // note that [super init] will call the SpaceshipNode's init method
    if (self = [super init]) {
        NSLog(@"A new NodePalette1L was just init'ed.");
        self = (NodePalette1L*) [[SKSpriteNode alloc]initWithImageNamed:@"NodePalette1L"];
        self.name =@"NodePalette1L";
    }
    return self;
}

@end
