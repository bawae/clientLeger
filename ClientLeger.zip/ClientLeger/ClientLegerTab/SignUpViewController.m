//
//  SignUpViewController.h
//  ClientLegerTab
//
//  Created by Mos on 26/11/2015.
//  Copyright (c) 2015 Mos. All rights reserved.
//

#import "SignUpViewController.h"
#import "LoginViewController.h"
#import "SessionSingleton.h"
#import "Parse/Parse.h"
#import "Constants.h"

@interface SignUpViewController ()
@property (weak, nonatomic) IBOutlet UITextField *usernameField;
@property (weak, nonatomic) IBOutlet UITextField *passwordField;
@property(nonatomic) NSMutableDictionary* userLogins;
@property(nonatomic) NSMutableDictionary* userProfile;
@property (weak, nonatomic) SessionSingleton* userSession;

@end

@implementation SignUpViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.inscrireButton.font = [UIFont fontWithName:@"AppleSDGothicNeo-SemiBold" size:20];
    self.annulerButton.font = [UIFont fontWithName:@"AppleSDGothicNeo-SemiBold" size:18];
    self.VisibilityLabel.font = [UIFont fontWithName:@"AppleSDGothicNeo-SemiBold" size:16];
    _userLogins = [NSMutableDictionary new];
    _userProfile = [NSMutableDictionary new];
    _userSession = [SessionSingleton sharedInstance];
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"backgroundPinBall"]];
    
    // Fetch and  all users
    [self getAllUsers];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (IBAction)inscrireClicked:(id)sender {
    
    NSString* usernameInput = _usernameField.text;
    NSString* passwordInput = _passwordField.text;
    NSString* prenomInput = self.prenomField.text;
    NSString* nomInput = self.nomField.text;
    
    if ([usernameInput isEqualToString:@""] || [passwordInput isEqualToString:@""] || [prenomInput isEqualToString:@""] || [nomInput isEqualToString:@""] ) {
        
        UIAlertView* alert = [[UIAlertView alloc] initWithTitle: @"Erreur inscription" message: @"Un champ est vide." delegate: self cancelButtonTitle: nil otherButtonTitles: @"Ok", nil];
        [alert setTag: 3];
        [alert show];
        return;
        
    }else{
        // Username existant
        if ([_userLogins valueForKey:usernameInput] != nil) {
            UIAlertView* alert = [[UIAlertView alloc] initWithTitle: @"Erreur inscription" message: @"Nom d'utilisateur existant. Veuillez choisir un autre nom d'utilisateur" delegate: self cancelButtonTitle: @"Annuler" otherButtonTitles: @"OK", nil];
            [alert setTag:0];
            [alert show];
            return;
        }else{
            // Sending data to parse
            PFObject *newUser = [PFObject objectWithClassName:PARSE_USER_CLASS];
            newUser[@"username"] = usernameInput;
            newUser[@"password"] = passwordInput;
            newUser[@"firstname"] = prenomInput;
            newUser[@"lastname"] = nomInput;
            
            NSString* public;
            if([self.visibiltySwitch isOn]){
                newUser[@"isPublic"] = @"true";
                public = @"true";
            }
            else{
                newUser[@"isPublic"] = @"false";
                public = @"false";
            }

            NSString* userXML = [self createUserXmlwithUsername:usernameInput passWord:passwordInput firstName:prenomInput lastname:nomInput public:public];
            
            NSData* userXmlData=[userXML dataUsingEncoding:NSUTF8StringEncoding];
            NSString* fileName = [NSString stringWithFormat:@"Utilisateur_%@.xml",usernameInput];
            PFFile* userXmlFile = [PFFile fileWithName:fileName data:userXmlData];
            [userXmlFile saveInBackgroundWithBlock:^(BOOL succeeded, NSError *error) {
                // save the object now
                newUser[@"userXml"] = userXmlFile;
                [newUser saveEventually];
            }];
            
           // [userXmlFile saveInBackground];
            //newUser[@"userXml"] = userXmlFile;
            //[newUser saveEventually];
            
            
            NSLog(@"LOG: New user created !");
            
            [_userSession  setUserName:usernameInput];
            _userSession->nom = nomInput;
            _userSession->prenom = prenomInput;
            _userSession->tempsJeu = @"0mn 0sec";
            _userSession->pgagne = @"0";
            _userSession->pperdue = @"0";
            _userSession->highscore = @"0";
            [_userSession  setUserPicure:[_userProfile valueForKey:usernameInput]];

            UIAlertView* alert = [[UIAlertView alloc] initWithTitle: @"Inscription réussie" message: @"Inscription réussie." delegate: self cancelButtonTitle: nil otherButtonTitles: @"OK", nil];
                      [alert setTag:1];
            [alert show];
            return;
        
        }
    }
}


- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    // Apres inscription let's go to the edition screen
    if(alertView.tag == 1){
        if (buttonIndex == 0)
        {
           // [self performSegueWithIdentifier:@"toTabController2" sender:nil];
            [self performSegueWithIdentifier:@"toTutorial" sender:nil];
        }

    }
}



- (PFQuery *) getAllUsers {
    PFQuery *query = [PFQuery queryWithClassName: PARSE_USER_CLASS];
    [query findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
        if (!error) {
            // The find succeeded.
            NSLog(@"Successfully retrieved %lu users.", (unsigned long)objects.count);
            // Do something with the found objects
            for (PFObject *object in objects) {
                [_userLogins setObject: object[@"password"] forKey:object[@"username"]];
                
                PFFile *picFile = object[@"profilePicture"];
                UIImage *image;
                if(picFile == nil) {
                    image = [UIImage imageNamed:@"no_map.jpg"];
                }else{
                    NSData* picData = [picFile getData];
                    image = [UIImage imageWithData:picData];
                }
                [_userProfile setObject:image forKey:object[@"username"]];
                
                
            }
        } else {
            // Log details of the failure
            NSLog(@"Error: %@ %@", error, [error userInfo]);
        }
    }];
    return query;
}


- (NSString*) createUserXmlwithUsername:(NSString*)username passWord:(NSString*)p firstName:(NSString*)f lastname:(NSString*)l public:(NSString*)public{

  
    NSCharacterSet *whitespace = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmedUsername = [username stringByTrimmingCharactersInSet:whitespace];
    NSString *trimmedPassword = [p stringByTrimmingCharactersInSet:whitespace];
    

    
    NSString* s1 = @"<?xml version=\"1.0\" encoding=\"UTF-8\" ?>";
    NSString* s2 = @"<Information username=";
    NSString* s3 = trimmedUsername ;
    NSString* s4 = @"password=";
    NSString* s5 = trimmedPassword;
    NSString* s6 = @"firstname=";
    NSString* s7 = f ;
    NSString* s8 = @"lastname=";
    NSString* s9 = l ;
    NSString* s10 = @"\"age=\"0\" gender=\"0\" profileprivacy=\"";
    NSString* s11 = public;
    NSString* s12 = @"\"playtime=\"0\" wins=\"0\" losses=\"0\" highscore=\"0\" friends=\"\"  image=\"\"  />";
    NSString* xmlString = [NSString stringWithFormat: @"%@ %@ %@ %@ %@ %@ %@ %@ %@ %@ %@ %@", s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12];
   // return xmlString;
    
   // NSString* xmlString = @"<?xml version=\"1.0\" encoding=\"UTF-8\" ?>" + "<Information username=\"" + userProfile.userName + "\" password=\"" + userProfile.passWord + "\" firstname=\"" + userProfile.firstName + "\" lastname=\"" + userProfile.lastName + "\" age=\"0\" gender=\"0\" profileprivacy=\"" + userProfile.isPublic + "\" playtime=\"0\" wins=\"0\" losses=\"0\" highscore=\"0\" friends=\"\"  image=\"\"  />";
    
    
    
    DDXMLDocument* xmlDoc = [[DDXMLDocument alloc]initWithXMLString:@"<Information/>" options:0 error:nil];
    DDXMLElement* xml_root = [xmlDoc rootElement];
    [xml_root addAttribute:[DDXMLNode attributeWithName:@"username" stringValue:trimmedUsername]];
    [xml_root addAttribute:[DDXMLNode attributeWithName:@"password" stringValue:trimmedPassword]];
    [xml_root addAttribute:[DDXMLNode attributeWithName:@"firstname" stringValue:f]];
    [xml_root addAttribute:[DDXMLNode attributeWithName:@"lastname" stringValue:l]];
    [xml_root addAttribute:[DDXMLNode attributeWithName:@"age" stringValue:@"0"]];
    [xml_root addAttribute:[DDXMLNode attributeWithName:@"gender" stringValue:@"Homme"]];
    [xml_root addAttribute:[DDXMLNode attributeWithName:@"profileprivacy" stringValue:public]];
    [xml_root addAttribute:[DDXMLNode attributeWithName:@"playtime" stringValue:@"0"]];
    [xml_root addAttribute:[DDXMLNode attributeWithName:@"wins" stringValue:@"0"]];
    [xml_root addAttribute:[DDXMLNode attributeWithName:@"losses" stringValue:@"0"]];
    [xml_root addAttribute:[DDXMLNode attributeWithName:@"highscore" stringValue:@"0"]];
    [xml_root addAttribute:[DDXMLNode attributeWithName:@"friends" stringValue:@""]];
    [xml_root addAttribute:[DDXMLNode attributeWithName:@"image" stringValue:@""]];
    NSData *xmlData = [xmlDoc XMLData];
    return [[NSString alloc]initWithData:xmlData encoding:NSUTF8StringEncoding];
}


@end
