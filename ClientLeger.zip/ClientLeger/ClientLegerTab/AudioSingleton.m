//
//  AudioSingleton.m
//  ClientLegerTab
//
//  Singleton qui gere la session d'un utilisateur
//  Created by Mouhamadou Oumar Sall on 21/11/2015.
//  Copyright (c) 2015 Mos. All rights reserved.
//

#import "AudioSingleton.h"

@implementation AudioSingleton

static AudioSingleton *sharedAudioSingleton = nil;    // static instance variable
static dispatch_once_t pred;


/*!
 * @discussion Methode qui retourne l'instance du MapSingleton
 *
 * @return MapSingleton
 */
+ (AudioSingleton *)sharedInstance {
    if (sharedAudioSingleton == nil) {
        dispatch_once(&pred, ^{
            sharedAudioSingleton = [[super allocWithZone:NULL] init];
        });
        sharedAudioSingleton->player = [[AudioController alloc]init];

    
    }
    return sharedAudioSingleton;
}



- (void)playBackgroundSound {
    [self->player playBackgroundMusic];

}
- (void)stopBackgroundSound {
    [self->player stopBackgroundMusic];
}

@end


