//
//  MapSingleton.m
//  ClientLegerTab
//
//  Singleton qui permet de determiner l'etat de la carte en cours d'edition
//  ainsi que la carte en cours de chargement
//  Created by Mouhamadou Oumar Sall on 21/11/2015.
//  Copyright (c) 2015 Mos. All rights reserved.
//

#import "LoadSingleton.h"

@implementation LoadSingleton

static LoadSingleton *sharedMapSingleton = nil;    // static instance variable
static dispatch_once_t pred;


/*!
 * @discussion Methode qui retourne l'instance du MapSingleton
 *
 * @return MapSingleton
 */
+ (LoadSingleton *)sharedInstance {
    if (sharedMapSingleton == nil) {
        dispatch_once(&pred, ^{
            sharedMapSingleton = [[super allocWithZone:NULL] init];
        });
        sharedMapSingleton->loadMode = false;
        sharedMapSingleton->currentMap = nil;
    }
    return sharedMapSingleton;
}


/*!
 * @discussion Setter du mode de MapSingleton (True = On a charge une carte)
 *
 * @param (BOOL) b
 */
- (void)setMode:(BOOL)b {
    loadMode = b;
}

/*!
 * @discussion Setter de la carte courante. (Charge)
 *
 * @param (DDXMLDocument*)doc
 */
- (void)setCurrentMap:(DDXMLDocument*)doc {
    currentMap = doc;
}

/*!
 * @discussion Getter du mode de MapSingleton
 *
 * @return BOOL:(True = On a charge une carte)
 */
- (BOOL)getMode {
    return loadMode;
}

/*!
 * @discussion Getter des donnees xml de la carte courante
 *
 * @return DDXMLDocument*
 */
- (DDXMLDocument*)getCurrentMap {
    return currentMap;
}

@end


