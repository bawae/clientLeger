//
//  NodeMur.m
//  
//
//  Created by Mos on 19/10/2015.
//
//

#import <Foundation/Foundation.h>
#import "NodeMur.h"
#import "Constants.h"

@implementation NodeMur

- (instancetype) init {
    // note that [super init] will call the SpaceshipNode's init method
    if (self = [super init]) {
        NSLog(@"A new NodeMur was just init'ed.");
        self = (NodeMur*) [[SKSpriteNode alloc]initWithImageNamed:@"NodeMur"];
        self.name =@"NodeMur";
        self.physicsBody = [SKPhysicsBody bodyWithEdgeLoopFromRect:self.frame];
        self.physicsBody.categoryBitMask = NFIXEDCATEGORY;
        self.physicsBody.dynamic = NO;

    }
    return self;
}
@end
