//
//  CardPropertyViewController.h
//  ClientLegerTab
//
//  Created by Mos on 26/11/2015.
//  Copyright (c) 2015 Mos. All rights reserved.


#import <UIKit/UIKit.h>

@interface CardPropertyViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *cardTitle;
@property (weak, nonatomic) IBOutlet UITextField *cardUser;
@property (weak, nonatomic) IBOutlet UITextField *cardDifficulty;
@property (weak, nonatomic) IBOutlet UITextField *cardPBC;
@property (weak, nonatomic) IBOutlet UITextField *cardPBT;
@property (weak, nonatomic) IBOutlet UITextField *cardPC;
@property (weak, nonatomic) IBOutlet UITextField *cardPBille;
@property (weak, nonatomic) IBOutlet UITextField *cardPPG;

@end

