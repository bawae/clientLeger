//
//  LoginViewController.h
//  ClientLegerTab
//
//  Created by Mos on 26/11/2015.
//  Copyright (c) 2015 Mos. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SessionSingleton.h"

@interface LoginViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *usernameField;
@property (weak, nonatomic) IBOutlet UITextField *passwordField;
@property (weak, nonatomic) SessionSingleton* userSession;
@property (weak, nonatomic) IBOutlet UIButton *inviteButton;
@property (weak, nonatomic) IBOutlet UIButton *connecterButton;
@property (weak, nonatomic) IBOutlet UIButton *inscrireButton;

@end

