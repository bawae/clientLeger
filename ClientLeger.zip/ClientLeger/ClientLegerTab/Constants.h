//
//  Constant.h
//  ClientLegerTab
//
//  Cette classe regroupe les variables contantes utilisées dans le projet
//  Created by Mouhamadou Oumar Sall on 07/11/2015.
//  Copyright (c) 2015 Mos. All rights reserved.
//

#import <Foundation/Foundation.h>
//Node
extern NSString * const NODE_TROU;
extern NSString * const NODE_PORTAIL;
extern NSString * const NODE_BUTOIRCIRCULAIRE;
extern NSString * const NODE_BUTOIRTRIANGULAIREL;
extern NSString * const NODE_BUTOIRTRIANGULAIRER;
extern NSString * const NODE_GENERATEUR;
extern NSString * const NODE_RESSORT;
extern NSString * const NODE_TABLE;
extern NSString * const NODE_MUR;

extern NSString * const NODE_PALETTE1R;
extern NSString * const NODE_PALETTE1L;
extern NSString * const NODE_PALETTE2R;
extern NSString * const NODE_PALETTE2L;

//Constantes pour les types de noeuds
extern NSString * const TYPE_RACINE;
extern NSString * const TYPE_RESSORT;
extern NSString * const TYPE_TROU;
extern NSString * const TYPE_PORTAIL;
extern NSString * const TYPE_GENERATEUR;
extern NSString * const TYPE_MUR;
extern NSString * const TYPE_BUTOIRCIRCULAIRE;
extern NSString * const TYPE_BUTOIRTRIANGULAIRER;
extern NSString * const TYPE_BUTOIRTRIANGULAIREL;
extern NSString * const TYPE_BTL;
extern NSString * const TYPE_CIBLE;
extern NSString * const TYPE_PALETTE1R;
extern NSString * const TYPE_PALETTE2R;
extern NSString * const TYPE_PALETTE1L;
extern NSString * const TYPE_PALETTE2L;
extern NSString * const TYPE_BILLE;
extern NSString * const TYPE_ZONE;

//Categories
static const uint32_t FIXEDCATEGORY = 0x1;
static const uint32_t NFIXEDCATEGORY = 0x1 << 1;
static const uint32_t EDGECATEGORY = 0x1 << 2;

// Carte points value
extern NSString * const PROP;
extern NSString * const DIFF;
extern NSString * const PBC;
extern NSString * const PBT;
extern NSString * const PPG;
extern NSString * const PB;
extern NSString * const PC;

//Parse constant
extern NSString * const PARSE_CARTE_CLASS;
extern NSString * const PARSE_USER_CLASS;


// Size Client Leger <-> Client Lourd

static const float xPlus = 190;
static const float yPlus = 260;
static const float dgRad = 180/3.14;

//-195, 195

//-264, 264


