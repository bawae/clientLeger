//
//  Constant.h
//  ClientLegerTab
//
//  Cette classe regroupe les variables contantes utilisées dans le projet
//  Created by Mouhamadou Oumar Sall on 07/11/2015.
//  Copyright (c) 2015 Mos. All rights reserved.


#import "VisitorXML.h"
#import "EditorScene.h"
#import "ParserXML.h"
#import "NodeHeader.h"
#import "NodeHeader.h"
#import "MapProperties.h"



@interface MapProperties ()
@end

@implementation MapProperties
- (instancetype) initWithDoc:(DDXMLDocument*)doc  {
    if (self = [super init]) {
        NSError *error;
        NSArray *points =[doc nodesForXPath:@"///Point" error:&error];
        for (DDXMLElement* point in points) {
            map_pbc = [[point attributeForName:@"PtsBC"]stringValue];
            map_pbt = [[point attributeForName:@"PtsBT"]stringValue];
            map_pc = [[point attributeForName:@"PtsCible"]stringValue];
            map_pb = [[point attributeForName:@"PtsNewBall"]stringValue];
            map_ppg = [[point attributeForName:@"PtsEndGame"]stringValue];
            map_cardDifficulty = [[point attributeForName:@"Difficulty"]stringValue];
        }
    }
    return self;
}
@end

