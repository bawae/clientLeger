//
//  LeaderBoardViewController.h
//  ClientLegerTab
//
//  Created by Mos on 16/11/2015.
//  Copyright (c) 2015 Mos. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "iCarousel.h"

@interface LeaderBoardViewController : UIViewController<UIWebViewDelegate>
    @property UIActivityIndicatorView *loadingIndicator;
@end

