//
//  NodeBille.h
//  
//
//  Created by Mos on 19/10/2015.
//
//

#import <Foundation/Foundation.h>
#import <SpriteKit/SpriteKit.h>
#import "AbstractNode.h"


@interface NodeBille:AbstractNode


@end




