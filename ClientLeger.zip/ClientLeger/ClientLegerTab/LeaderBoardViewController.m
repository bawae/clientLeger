//
//  LeaderBoardViewController.m
//  ClientLegerTab
//
//  Created by Mos on 29/11/2015.
//      Inspired by https://github.com/nicklockwood/iCarousel
//  Copyright (c) 2015 Mos. All rights reserved.
//

#import "LeaderBoardViewController.h"
#import "Constants.h"
#import "LoadSingleton.h"
#import "MapSingleton.h"
#import "Utility.h"
#import <Parse/Parse.h>

@interface LeaderBoardViewController ()
@property (weak, nonatomic) IBOutlet UIWebView *webView;

@end



@implementation LeaderBoardViewController


- (void) awakeFromNib {
    //bysolutions.ca/log3900-02
    
    
    
}
- (void)viewDidLoad {
    // Indicateur
    _loadingIndicator = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(145, 190, 20,20)];
    [_loadingIndicator setActivityIndicatorViewStyle:UIActivityIndicatorViewStyleGray];
    [_loadingIndicator setHidesWhenStopped:YES];
    NSMutableURLRequest * request =[NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://www.bysolutions.ca/log3900-02"]];
    
    [self.webView addSubview:_loadingIndicator];
    [self.webView loadRequest:request];
}

- (void) webViewDidStartLoad:(UIWebView *)webView{
    [_loadingIndicator startAnimating];
}

- (void) webViewDidFinishLoad:(UIWebView *)webView{
    [_loadingIndicator stopAnimating];
}
@end
