//
//  Constant.h
//  ClientLegerTab
//
//  Cette classe regroupe les variables contantes utilisées dans le projet
//  Created by Mouhamadou Oumar Sall on 07/11/2015.
//  Copyright (c) 2015 Mos. All rights reserved.
//
#import <Foundation/Foundation.h>
#import "AbstractNode.h"
#import "DDXML.h"

@interface MapProperties : NSObject  {
    
   @public NSString* mapTitle;
   @public NSString* mapUser;
   @public NSString* mapId;
   @public NSString* map_pbc;
   @public NSString* map_pbt;
   @public NSString* map_ppg;
   @public NSString* map_pb;
   @public NSString* map_pc;
   @public NSString* map_cardDifficulty;
}

- (instancetype) initWithDoc:(DDXMLDocument*)doc;

@end