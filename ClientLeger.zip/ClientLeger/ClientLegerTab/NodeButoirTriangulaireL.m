//
//  NodeButoirTriangulaireL.m
//  
//
//  Created by Mos on 19/10/2015.
//
//

#import <Foundation/Foundation.h>
#import "NodeButoirTriangulaireL.h"


@implementation NodeButoirTriangulaireL

- (instancetype) init {
    // note that [super init] will call the SpaceshipNode's init method
    if (self = [super init]) {
        NSLog(@"A new NodeButoirTriangulaireL was just init'ed.");
        self = (NodeButoirTriangulaireL*) [[SKSpriteNode alloc]initWithImageNamed:@"NodeButoirTriangulaireL"];
        self.name =@"NodeButoirTriangulaireL";

   
    }
    return self;
}
@end
