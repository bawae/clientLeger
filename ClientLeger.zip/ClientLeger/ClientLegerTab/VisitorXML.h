//
//  VisitorXML.h
//  ClientLegerTab
//
//  Classe qui se charge de parcourir une scene et de
//  creer une representation xml des noeuds
//
//  Created by Mos on 03/11/2015.
//  Copyright (c) 2015 Mos. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AbstractNode.h"
#import "DDXML.h"

@class EditorScene;
@interface VisitorXML : NSObject  {
    DDXMLDocument* doc_;
    DDXMLElement* racine_;

}

- (instancetype) initWithDoc:(DDXMLDocument*)doc rootElem:(DDXMLElement*)racine ;
- (NSString *) getString;
- (void) visitS:(EditorScene*) scene;

@end