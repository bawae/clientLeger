//
//  ProfileViewController.h
//  ClientLegerTab
//
//  Created by Mouhamadou Oumar Sall on 26/11/2015.
//  Copyright (c) 2015 Mos. All rights reserved.
//

#import "ProfileViewController.h"
#import "SessionSingleton.h"
#import "Utility.h"
#import "Constants.h"
#import "AudioController.h"
#import "AudioSingleton.h"
#import <Parse/Parse.h>
#import "LoginViewController.h"




@interface ProfileViewController ()

@property (weak, nonatomic) IBOutlet UIView *profilePicView;
@property (weak, nonatomic) IBOutlet UITextField *profileUserName;
@property (weak, nonatomic) NSString* userId; // the id of the user for updating he image
@property (weak, nonatomic) IBOutlet UILabel *prenomField;
@property (weak, nonatomic) IBOutlet UILabel *nomField;

@property (weak, nonatomic) IBOutlet UILabel *tempsJeuField;
@property (weak, nonatomic) IBOutlet UILabel *partieGagneField;
@property (weak, nonatomic) IBOutlet UILabel *partiePerduField;
@property (weak, nonatomic) IBOutlet UILabel *scoreHighField;


@end

@implementation ProfileViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"backgroundPinBall"]];
    
    //Creating a circular view
    _profilePicView.layer.cornerRadius = self.profilePicView.frame.size.width / 2;
    _profilePicView.clipsToBounds = YES;
    _profilePicView.layer.borderWidth = 3.0f;
    _profilePicView.layer.borderColor = [UIColor whiteColor].CGColor;
    _profilePicView.layer.cornerRadius = 10.0f;
    _profileUserName.text = [[SessionSingleton sharedInstance] getUsername];
    
    //Resized picture profile
    UIImage* resizedPic = [Utility imageWithImage:[[SessionSingleton sharedInstance] getUserPicture] scaledToSize:_profilePicView.frame.size];
    
    //User data
    self.profilePicView.backgroundColor = [UIColor colorWithPatternImage:resizedPic];
    self.prenomField.text = [SessionSingleton sharedInstance]->prenom;
    self.nomField.text = [SessionSingleton sharedInstance]->nom;
    self.tempsJeuField.text = [SessionSingleton sharedInstance]->tempsJeu;
    self.partieGagneField.text = [SessionSingleton sharedInstance]->pgagne;
    self.partiePerduField.text = [SessionSingleton sharedInstance]->pperdue;
    self.scoreHighField.text = [SessionSingleton sharedInstance]->highscore;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)didTapProfilePicture:(id)sender {
    NSLog(@"Profile picture taped");
    UIActionSheet *actionSheet;
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]){
        actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate: self cancelButtonTitle:@"Annuler" destructiveButtonTitle:nil otherButtonTitles:@"Choisir une Photo",@"Prendre une photo", nil];
    }else{
        actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate: self cancelButtonTitle:@"Annuler" destructiveButtonTitle:nil otherButtonTitles:@"Choisir une Photo", nil];
    }
    
    [actionSheet showFromRect:self.profilePicView.frame inView:self.view animated:YES];
}


-(void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex{

    if (buttonIndex == 0) {
        UIImagePickerController *imagePickerController = [[UIImagePickerController alloc]init];
        imagePickerController.delegate = self;
        imagePickerController.sourceType =  UIImagePickerControllerSourceTypePhotoLibrary;
        [self presentModalViewController:imagePickerController animated:YES];
    }else if (buttonIndex == 1){
        [self startCamera];
    }
}

- (void) gettingUserId{
    NSString* username = [[SessionSingleton sharedInstance] getUsername];
    if(username != nil){
        PFQuery *query = [PFQuery queryWithClassName:PARSE_USER_CLASS];
        [query whereKey:@"username" equalTo:username];
        NSArray* a = [query findObjects];
        PFObject* o = a[0];
        _userId = o.objectId;
    }
    
}


#pragma Camera Handler
// Inspired by: http://iosdevelopertips.com/camera/camera-application-to-take-pictures-and-save-images-to-photo-album.html
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    [picker dismissModalViewControllerAnimated:YES];
    UIImage *pickedImage = [Utility scaleAndRotateImage:[info objectForKey:UIImagePickerControllerOriginalImage]];
    _profilePicView.backgroundColor=[UIColor colorWithPatternImage:[Utility imageWithImage:pickedImage scaledToSize:_profilePicView.frame.size]];
    
    //Create the PFfiLe
    NSData* userImage = UIImagePNGRepresentation(pickedImage);
    PFFile *imageFile = [PFFile fileWithName:@"profilePicture.png" data:userImage];
    [imageFile saveInBackground];
    
    // Upload image to parse
    PFQuery *query = [PFQuery queryWithClassName:PARSE_USER_CLASS];
    
    // Retrieve the object by id
    [self gettingUserId];
    [query getObjectInBackgroundWithId:_userId
                                 block:^(PFObject *user, NSError *error) {
                                     //User profile
                                     user[@"profilePicture"] = imageFile;
                                     [user saveInBackground];
                                 }];
    
}

-(void) startCamera{
    // Create image picker controller
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    // Set source to the camera
    imagePicker.sourceType =  UIImagePickerControllerSourceTypeCamera;
    // Delegate is self
    imagePicker.delegate = self;
    // Allow editing of image ?
    imagePicker.allowsImageEditing = NO;
    // Show image picker
    [self presentModalViewController:imagePicker animated:YES];
}

- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo
{
    UIAlertView *alert;
    // Unable to save the image
    if (error)
        alert = [[UIAlertView alloc] initWithTitle:@"Error"
                                           message:@"Unable to save image to Photo Album."
                                          delegate:self cancelButtonTitle:@"Ok"
                                 otherButtonTitles:nil];
    else // All is well
        alert = [[UIAlertView alloc] initWithTitle:@"Success"
                                           message:@"Image saved to Photo Album."
                                          delegate:self cancelButtonTitle:@"Ok"
                                 otherButtonTitles:nil];
    [alert show];
}

- (IBAction)deconnexionClicked:(id)sender {

    
    AudioSingleton * sound = [AudioSingleton sharedInstance];
    [sound stopBackgroundSound];
    [self performSegueWithIdentifier:@"deconnexion" sender:nil];

}


@end
