//
//  SecondViewController.m
//  ClientLegerTab
//
//  Created by Mos on 26/10/2015.
//  Copyright (c) 2015 Mos. All rights reserved.
//

#import "PageViewController.h"
#import "MapSingleton.h"
#import "Utility.h"


@interface PageViewController ()

@end

@implementation PageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

@end
