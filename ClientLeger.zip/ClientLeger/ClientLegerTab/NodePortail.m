//
//  NodePortail.m
//  
//
//  Created by Mos on 19/10/2015.
//
//

#import <Foundation/Foundation.h>

#import "NodePortail.h"

@implementation NodePortail

- (instancetype) init {
    // note that [super init] will call the SpaceshipNode's init method
    if (self = [super init]) {
        NSLog(@"A new NodePalette1L was just init'ed.");
        self = (NodePortail*) [[SKSpriteNode alloc]initWithImageNamed:@"NodePortail"];
        self.name =@"NodePortail";
    }
    return self;
}

@end
