//
//  NodeBille.m
//  
//
//  Created by Mos on 19/10/2015.
//
//

#import <Foundation/Foundation.h>

#import "NodePalette2R.h"

@implementation NodePalette2R

- (instancetype) init {
    // note that [super init] will call the SpaceshipNode's init method
    if (self = [super init]) {
        NSLog(@"A new NodePalette2R was just init'ed.");
        self = (NodePalette2R*) [[SKSpriteNode alloc]initWithImageNamed:@"NodePalette2R"];
        self.name =@"NodePalette2R";
    }
    return self;
}

@end
