//
//  AbstractNode.h
//  
//
//  Created by Mos on 19/10/2015.
//
//

#import <SpriteKit/SpriteKit.h>

@interface AbstractNode : SKSpriteNode
@property(atomic) NSString * type;
@end

