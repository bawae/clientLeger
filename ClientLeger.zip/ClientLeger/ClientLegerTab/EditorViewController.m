//
//  EditorViewController.h
//  ClientLeger
//
//  Controlleur et vue du mode edition
//
//  Created by Mouhamadou Oumar Sall on 18/10/2015.
//  Copyright (c) 2015 Mos All rights reserved.
//

#import "EditorViewController.h"
#import "EditorScene.h"
#import "Constants.h"
#import "LoadSingleton.h"
#import "ParserXML.h"
#import "AudioController.h"
#import "AudioSingleton.h"


@implementation EditorViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.audioController = [[AudioController alloc]init];
    //[self.audioController playBackgroundMusic];
    
    AudioSingleton * sound = [AudioSingleton sharedInstance];
    [sound playBackgroundSound];
    // Configure the view.
    SKView * skView = (SKView *)self.view;
    if (!skView.scene) {
        skView.showsFPS = NO;
        skView.showsNodeCount = NO;
        // Create and configure the scene.
        SKScene * scene = [EditorScene sceneWithSize:skView.bounds.size];
        scene.scaleMode = SKSceneScaleModeAspectFill;
        
        // Present the scene.
        [skView presentScene:scene];
        NSLog(@"Editor will layout subview");
    }
}

- (void) viewWillAppear:(BOOL)animated {
    
    if([[LoadSingleton sharedInstance] getMode] == TRUE) {
        NSLog(@"Editor will appear LoadedMap");
        SKView * skView = (SKView *)self.view;
        SKScene * scene = [EditorScene sceneWithSize:skView.bounds.size withFile:[[LoadSingleton sharedInstance] getCurrentMap]];
        
        // On retire les gestures s'il y en a.
        for (UIGestureRecognizer *gesture in skView.gestureRecognizers) {
            [skView removeGestureRecognizer:gesture];
        }
        // On retire l'ensemble des noeuds initiaux
        [scene removeAllChildren];
        [scene removeFromParent];
        
        scene.scaleMode = SKSceneScaleModeAspectFill;
        [skView presentScene:scene];
        [[LoadSingleton sharedInstance]setMode:false];
    }else
        NSLog(@"Editor will appear ");
    
    
}

- (BOOL)shouldAutorotate
{
    return YES;
}

- (NSUInteger)supportedInterfaceOrientations
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return UIInterfaceOrientationMaskAllButUpsideDown;
    } else {
        return UIInterfaceOrientationMaskAll;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (BOOL)prefersStatusBarHidden {
    return YES;
}

-(void) viewWillDisappear:(BOOL)animated{
   // [self.audioController stopBackgroundMusic];
}

@end
