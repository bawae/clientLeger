//
//  CarteViewController.m
//  ClientLegerTab
//
//  Created by Mos on 16/11/2015.
//  Inspired by https://github.com/nicklockwood/iCarousel
//  Copyright (c) 2015 Mos. All rights reserved.
//

#import "CarteViewController.h"
#import "Constants.h"
#import "LoadSingleton.h"
#import "MapSingleton.h"
#import "MapProperties.h"

#import "Utility.h"
#import <Parse/Parse.h>

@interface CarteViewController ()
@property (nonatomic, strong) NSMutableArray *items;
@property (nonatomic, strong) NSMutableArray *itemsPic;
@property (nonatomic, strong) NSMutableArray *itemsXML;
@property (nonatomic, strong) NSMutableArray *itemsProperties;
@property (nonatomic, strong) NSMutableArray *itemsUser;
@end


#pragma mark -
#pragma mark View lifecycle

@implementation CarteViewController

- (void)awakeFromNib
{
    self.items = [NSMutableArray array];
    self.itemsPic = [NSMutableArray array];
    self.itemsXML = [NSMutableArray array];
    self.itemsProperties = [NSMutableArray array];
    self.itemsUser = [NSMutableArray array];
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"backgroundPinBall"]];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.items = [NSMutableArray array];
    self.itemsPic = [NSMutableArray array];
    self.itemsXML = [NSMutableArray array];
    self.itemsProperties = [NSMutableArray array];
    self.itemsUser = [NSMutableArray array];
    [self getAllCards];
    _caroussel.type = iCarouselTypeCoverFlow2;
    NSLog(@"viewWillAppear -- Card");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark -
#pragma mark iCarousel methods

- (NSInteger)numberOfItemsInCarousel:(iCarousel *)carousel
{
    //return the total number of items in the carousel
    return [_items count];
}

- (UIView *)carousel:(iCarousel *)caroussel viewForItemAtIndex:(NSInteger)index reusingView:(nullable UIView *)view
{
    UILabel *label = nil;
    UIImage *picture = [CarteViewController imageWithImage:_itemsPic[index] scaledToSize:CGSizeMake(500,500)];
    
    //create new view if no view is available for recycling
    if (view == nil)
    {
        view = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 500.0f, 500.0f)];
        view.backgroundColor=[UIColor colorWithPatternImage:picture];
        view.contentMode = UIViewContentModeCenter;
    }
    else
    {
        //get a reference to the label and picView in the recycled view
        label = (UILabel *)[view viewWithTag:1];
    }
    return view;
}


- (void)carousel:(iCarousel *)carousel didSelectItemAtIndex:(NSInteger)index {
    NSLog(@"View taped %ld", (long)index);
    
    UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"Ouvrir carte"
                                                                   message:@"Voulez-vous ouvrir cette carte? Votre edition courante sera perdue"
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault
                                                     handler:^(UIAlertAction * action) {
                                                         LoadSingleton * ms =[LoadSingleton sharedInstance];
                                                         [ms setMode:TRUE];
                                                         NSError* error = [NSError new];
                                                         NSData * xmlData = [Utility XMLStringFormat:_itemsXML[index]];
                                                         DDXMLDocument* currentMap = [[DDXMLDocument alloc]initWithData:xmlData options:0 error:&error];
                                                         
                                                         [ms setCurrentMap:currentMap];
                                                         //Setting map properties
                                                         MapProperties* mapProp = self.itemsProperties[index];
                                                         [[MapSingleton sharedInstance] setCardTitle:mapProp->mapTitle];
                                                         [[MapSingleton sharedInstance] setCardUser:mapProp->mapUser];
                                                         [[MapSingleton sharedInstance] setCardId:mapProp->mapId];
                                                         [[MapSingleton sharedInstance] setCardDifficulty:[mapProp->map_cardDifficulty intValue]];
                                                         [[MapSingleton sharedInstance] setCardpbcirculaire:[mapProp->map_pbc intValue]];
                                                         [[MapSingleton sharedInstance] setCardpbtriangulaire:[mapProp->map_pbt intValue]];
                                                         [[MapSingleton sharedInstance] setCardpcible:[mapProp->map_pc  intValue]];
                                                         [[MapSingleton sharedInstance] setCardpbille:[mapProp->map_pb  intValue]];
                                                         [[MapSingleton sharedInstance] setCardpgagner:[mapProp->map_ppg  intValue]];

                                                         [self.tabBarController setSelectedIndex:0];
                                                         
                                                     }];
    UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:@"Annuler" style:UIAlertActionStyleDefault
                                                         handler:^(UIAlertAction * action) {
                                                             
                                                         }];
    
    [alert addAction:okAction];
    [alert addAction:cancelAction];
    [self presentViewController:alert animated:YES completion:nil];
    
    
}


#pragma mark -
#pragma mark Data methods

- (PFQuery *) getAllCards {
    PFQuery *query = [PFQuery queryWithClassName: PARSE_CARTE_CLASS];
    [query findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
        if (!error) {
            // The find succeeded.
            NSLog(@"Successfully retrieved %lu cards.", (unsigned long)objects.count);
            // Getting properties from the found maps
            for (PFObject *object in objects) {
                NSLog(@"%@", object.objectId);
                [_items addObject: object[@"user"]];
                PFFile *picFile = object[@"cardPicture"];
                UIImage *image;
                if(picFile == nil) {
                    image = [UIImage imageNamed:@"no_map.jpg"];
                }else{
                    NSData* picData = [picFile getData];
                    image = [UIImage imageWithData:picData];
                }
                [_itemsPic addObject:image];
                PFFile *xmlFile = object[@"cardXML"];
                [_itemsXML addObject:[xmlFile getData]];
                
                //Getting map properties
                NSData * xmlData = [Utility XMLStringFormat:[xmlFile getData]];
                DDXMLDocument* mapDoc = [[DDXMLDocument alloc]initWithData:xmlData options:0 error:&error];
                MapProperties* mapProp = [[MapProperties alloc]initWithDoc:mapDoc];
                mapProp->mapUser = object[@"user"];
                mapProp->mapTitle = object[@"name"];
                mapProp->mapId = object.objectId;
                [self.itemsProperties addObject:mapProp];
                
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.caroussel reloadData];
            });
        } else {
            // Log details of the failure
            NSLog(@"Error: %@ %@", error, [error userInfo]);
        }
    }];
    return query;
}

// Sources : http://stackoverflow.com/questions/2658738/the-simplest-way-to-resize-an-uiimage
+ (UIImage *)imageWithImage:(UIImage *)image scaledToSize:(CGSize)newSize {
    //UIGraphicsBeginImageContext(newSize);
    // In next line, pass 0.0 to use the current device's pixel scaling factor (and thus account for Retina resolution).
    // Pass 1.0 to force exact pixel size.
    UIGraphicsBeginImageContextWithOptions(newSize, NO, 0.0);
    [image drawInRect:CGRectMake(0, 0, newSize.width, newSize.height)];
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
}


- (void)carouselDidEndScrollingAnimation:(iCarousel *)carousel1
{
    int index=carousel1.currentItemIndex;
    if (index < [self.itemsProperties count] ){
        MapProperties* mapProp = self.itemsProperties[index];
        _propioLabel.text = [PROP stringByAppendingString : mapProp->mapUser];
        _DifficulteLabel.text = [DIFF stringByAppendingString : mapProp->map_cardDifficulty];
        _pbcLabel.text = [PBC stringByAppendingString : mapProp->map_pbc];
        _pbtLabel.text = [PBT stringByAppendingString : mapProp->map_pbt];
        _pcLabel.text = [PC stringByAppendingString : mapProp->map_pc];
        _pbLabel.text = [PB stringByAppendingString : mapProp->map_pb];
        _ppg.text = [PPG stringByAppendingString : mapProp->map_ppg];
        NSLog(@"%d", index);
    }
}

@end
