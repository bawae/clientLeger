//
//  LoginViewController.m
//  ClientLegerTab
//
//  Created by Mos on 26/11/2015.
//  Copyright (c) 2015 Mos. All rights reserved.
//

#import "LoginViewController.h"
#import "SessionSingleton.h"
#import "Parse/Parse.h"
#import "AudioController.h"
#import "Constants.h"

@interface LoginViewController ()
@property(nonatomic) NSMutableDictionary* userLogins;
@property(nonatomic) NSMutableDictionary* userProfile;
@property(nonatomic) NSMutableDictionary* userNom;
@property(nonatomic) NSMutableDictionary* userPrenom;
@property(nonatomic) NSMutableDictionary* userTempsJeu;
@property(nonatomic) NSMutableDictionary* userPgagne;
@property(nonatomic) NSMutableDictionary* userPperdue;
@property(nonatomic) NSMutableDictionary* userHighscore;

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    // Do any additional setup after loading the view, typically from a nib.
    self.inscrireButton.font = [UIFont fontWithName:@"AppleSDGothicNeo-SemiBold" size:20];
    self.inviteButton.font = [UIFont fontWithName:@"AppleSDGothicNeo-SemiBold" size:20];
    self.connecterButton.font = [UIFont fontWithName:@"AppleSDGothicNeo-SemiBold" size:20];
    _userLogins = [NSMutableDictionary new];
    _userProfile = [NSMutableDictionary new];
    _userNom = [NSMutableDictionary new];
    _userPrenom = [NSMutableDictionary new];
    _userTempsJeu = [NSMutableDictionary new];
    _userPgagne = [NSMutableDictionary new];
    _userPperdue = [NSMutableDictionary new];
    _userHighscore = [NSMutableDictionary new];
    _userSession = [SessionSingleton sharedInstance];
    
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"backgroundPinBall"]];
    
    // Fetch and  all users
    [self getAllUsers];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (IBAction)seConnecterClicked:(id)sender {
    
    //Verify of username and passwrod are valid
    NSString* userUsernameInput = _usernameField.text;
    NSString* userPasswordInput = _passwordField.text;
    
    //Verify of username and passwrod are valid
    NSString* test  = [_userLogins valueForKey:userUsernameInput];
    if (![[_userLogins valueForKey:userUsernameInput] isEqualToString:userPasswordInput ]){
        UIAlertView* alert = [[UIAlertView alloc] initWithTitle: @"Erreur connexion" message: @"Nom d'utilisateur et/ou mot de passe invalide" delegate: self cancelButtonTitle: @"Annuler" otherButtonTitles: @"Ok", nil];
        
        [alert show];
        return;

    }
    
    [_userSession  setUserName:userUsernameInput];
    [_userSession  setUserPassword:userPasswordInput];
    [_userSession  setUserPicure:[_userProfile valueForKey:userUsernameInput]];
    _userSession->nom = [_userNom valueForKey:userUsernameInput];
    _userSession->prenom = [_userPrenom valueForKey:userUsernameInput];
    _userSession->tempsJeu = [_userTempsJeu valueForKey:userUsernameInput];
    _userSession->pgagne = [_userPgagne valueForKey:userUsernameInput];
    _userSession->pperdue = [_userPperdue valueForKey:userUsernameInput];
    _userSession->highscore = [_userHighscore valueForKey:userUsernameInput];

    
   // [self performSegueWithIdentifier:@"toTabController" sender:nil];
    [self performSegueWithIdentifier:@"toTutorial" sender:nil];
}


#pragma mark -
#pragma mark Data methods

- (PFQuery *) getAllUsers {
    PFQuery *query = [PFQuery queryWithClassName: PARSE_USER_CLASS];
    [query findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
        if (!error) {
            // The find succeeded.
            NSLog(@"Successfully retrieved %lu users.", (unsigned long)objects.count);
            // Do something with the found objects
            for (PFObject *object in objects) {
                [_userLogins setObject: object[@"password"] forKey:object[@"username"]];
                PFFile *picFile = object[@"profilePicture"];
                UIImage *image;
                
                if(picFile == nil) {
                    image = [UIImage imageNamed:@"icon-user-default.png"];
                }else{
                    NSData* picData = [picFile getData];
                    image = [UIImage imageWithData:picData];
                }
                [_userProfile setObject:image forKey:object[@"username"]];
                if(object[@"lastname"]==nil){
                    [_userNom setObject:@"Guest"  forKey:object[@"username"]];

                }else{
                    [_userNom setObject:object[@"lastname"] forKey:object[@"username"]];
                }
                
                //firstname
                if(object[@"firstname"]==nil){
                    [_userPrenom setObject:@"Guest"  forKey:object[@"username"]];
                    
                }else{
                    [_userPrenom setObject:object[@"firstname"] forKey:object[@"username"]];
                }
                
                //playtime
                if(object[@"playtime"]==nil){
                    [_userTempsJeu setObject:@"0mn 0sec"  forKey:object[@"username"]];
                    
                }else{
                    [_userTempsJeu setObject:object[@"playtime"] forKey:object[@"username"]];
                }
                
                //wins
                if(object[@"wins"]==nil){
                    [_userPgagne setObject:@"0"  forKey:object[@"username"]];
                    
                }else{
                    [_userPgagne setObject:object[@"wins"] forKey:object[@"username"]];
                }
                //highscore
                
                if(object[@"wins"]==nil){
                    [_userHighscore setObject:@"0"  forKey:object[@"username"]];
                }else{
                        [_userHighscore setObject:object[@"highscore"] forKey:object[@"username"]];
                }

                //losses
                if(object[@"losses"]==nil){
                    [_userPperdue setObject:@"0"  forKey:object[@"username"]];
                    
                }else{
                    [_userPperdue setObject:object[@"losses"] forKey:object[@"username"]];
                }
          }
            
        } else {
            // Log details of the failure
            NSLog(@"Error: %@ %@", error, [error userInfo]);
        }
    }];
    return query;
}

@end
