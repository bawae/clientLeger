//
//  PageContentViewController.h
//  ClientLeger_
//
//  Classe qui contient la logique de l'edition
//
//  Created by Mouhamadou Oumar on 18/10/2015.
//  InspiredBy com.TheAppGuruz. All rights reserved.

#import <UIKit/UIKit.h>

@interface PageContentViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *gifView;
@property (weak, nonatomic) IBOutlet UITextView *textView;

@property  NSUInteger pageIndex;
@property  NSString *gifUrl;
@property  NSString *instructionText;
@end

