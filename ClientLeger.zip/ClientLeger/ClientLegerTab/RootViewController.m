//
//  RootViewController.m
//  ClientLeger_
//
//  Classe qui contient la logique de l'edition
//
//  Created by Mouhamadou Oumar on 18/10/2015.
//  InspiredBy com.TheAppGuruz. All rights reserved.

#import "RootViewController.h"
#import "TabBarViewController.h"

@interface RootViewController ()
@property (weak, nonatomic) IBOutlet UIButton *skipTutoButton;

@end

@implementation RootViewController

@synthesize PageViewController,arrayInstruction,arrayGifUrl;

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.skipTutoButton.font = [UIFont fontWithName:@"Noteworthy-Bold" size:16];

        self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"backgroundPinBallProp"]];
    
    NSString* ajout = @"▶︎Ajout d'un noeud:\nPour ajouter un noeud à la zone de jeu, il suffit de glisser déposer un noeud du menu à l’intérieur de la zone d’édition.";
    
    NSString* operation = @"▶︎Opérations sur les noeuds:\nPour effectuer les différentes opérations sur les noeuds telles que la rotation,la mise à échelle, la duplication, la suppression entre autre, Il suffit de:\n1 - Sélectionner le noeud en faisant un double-tap.\n2 - Faire un appui long sur le noeud pour afficher le menu des opérations.\n3 - Choisir une opération.";
    
    NSString* proprietes = @"▶︎Modification des propritès d’une carte.\nPour modifier les propriétés d’une carte, il suffit de:\n 1 - Cliquer sur le bouton propriétés cartes en bas de la zone d'édition.";
    
    NSString* save = @"▶︎Enregistrement d’une carte.\nPour enregistrer une carte il suffit de:\n1 - Cliquer avec deux doigts sur la carte pour afficher le menu de sauvegarde.\n2 - Choisir une opération de sauvegarde.\n3 - Les cartes enregistrées seront visibles en cliquant sur l’onglet Cartes.";
    
    
    NSString* load = @"▶︎Chargement d’une carte.\n Pour ouvrir une carte saubegardée, Il suffit de:\n1 - Cliquer sur l’onglet cartes.\n2 - Choisir une carte.\n3 - Cliquer sur Ouvrir.";
    arrayInstruction = @[ajout, operation, proprietes, save, load];
    
    NSString* createG = @"https://drive.google.com/uc?export=download&id=0Bw0fmqX0oC9YUWdnaE16bW5wVDQ";
    NSString* scaleG = @"https://drive.google.com/uc?export=download&id=0Bw0fmqX0oC9YQURTV2o2UzRIM2s";
    NSString* rotateG = @"https://drive.google.com/uc?export=download&id=0Bw0fmqX0oC9YQnhjeWhvTWtTSnc";
    NSString* proprietesG = @"https://drive.google.com/uc?export=download&id=0Bw0fmqX0oC9YeUNlTjRxb0c1TFE";
    NSString* saveG = @"https://drive.google.com/uc?export=download&id=0Bw0fmqX0oC9YZ1lFem1NdjRJVFk";
    NSString* loadG = @"https://drive.google.com/uc?export=download&id=0Bw0fmqX0oC9YZnI2bnRKUGVNMmc";
    
    arrayGifUrl =@[createG, scaleG, proprietesG, saveG, loadG];
    
    // Create page view controller
    self.PageViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"PageViewController"];
    self.PageViewController.dataSource = self;
    
    PageContentViewController *startingViewController = [self viewControllerAtIndex:0];
    NSArray *viewControllers = @[startingViewController];
    [self.PageViewController setViewControllers:viewControllers direction:UIPageViewControllerNavigationDirectionForward animated:NO completion:nil];
    
    // Change the size of page view controller
    self.PageViewController.view.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height - 30);
    
    [self addChildViewController:PageViewController];
    [self.view addSubview:PageViewController.view];
    [self.PageViewController didMoveToParentViewController:self];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - Page View Datasource Methods
- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerBeforeViewController:(UIViewController *)viewController
{
    NSUInteger index = ((PageContentViewController*) viewController).pageIndex;
    
    if ((index == 0) || (index == NSNotFound))
    {
        return nil;
    }
    
    index--;
    return [self viewControllerAtIndex:index];
}

- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerAfterViewController:(UIViewController *)viewController
{
    NSUInteger index = ((PageContentViewController*) viewController).pageIndex;
    
    if (index == NSNotFound)
    {
        return nil;
    }
    
    index++;
    if (index == [self.arrayInstruction count])
    {
        return nil;
    }
    return [self viewControllerAtIndex:index];
}

#pragma mark - Other Methods
- (PageContentViewController *)viewControllerAtIndex:(NSUInteger)index
{
    if (([self.arrayInstruction count] == 0) || (index >= [self.arrayInstruction count])) {
        return nil;
    }
    
    // Create a new view controller and pass suitable data.
    PageContentViewController *pageContentViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"PageContentViewController"];
    pageContentViewController.gifUrl = self.arrayGifUrl[index];
    pageContentViewController.instructionText = self.arrayInstruction[index];
    pageContentViewController.pageIndex = index;
    
    return pageContentViewController;
}

#pragma mark - No of Pages Methods
- (NSInteger)presentationCountForPageViewController:(UIPageViewController *)pageViewController
{
    return [self.arrayInstruction count];
}

- (NSInteger)presentationIndexForPageViewController:(UIPageViewController *)pageViewController
{
    return 0;
}

- (IBAction)btnStartAgain:(id)sender
{
    PageContentViewController *startingViewController = [self viewControllerAtIndex:0];
    NSArray *viewControllers = @[startingViewController];
    [self.PageViewController setViewControllers:viewControllers direction:UIPageViewControllerNavigationDirectionReverse animated:NO completion:nil];
}

- (IBAction)skipTutorielClicked:(id)sender {

    [self performSegueWithIdentifier:@"afterTutorial" sender:nil];
}

@end
