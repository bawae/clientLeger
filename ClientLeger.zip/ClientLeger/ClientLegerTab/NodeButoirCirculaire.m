//
//  NodeButoirCirculaire.m
//  
//
//  Created by Mos on 19/10/2015.
//
//

#import <Foundation/Foundation.h>
#import "NodeButoirCirculaire.h"
#import "Constants.h"


@implementation NodeButoirCirculaire

- (instancetype) init {
    // note that [super init] will call the SpaceshipNode's init method
    if (self = [super init]) {
        NSLog(@"A new NodeButoirCirculaire was just init'ed.");
        self = (NodeButoirCirculaire*) [[SKSpriteNode alloc]initWithImageNamed:@"NodeButoirCirculaire"];
        self.name =@"NodeButoirCirculaire";
        self.physicsBody = [SKPhysicsBody bodyWithCircleOfRadius:self.frame.size.width/2 ];
        self.physicsBody.categoryBitMask = NFIXEDCATEGORY;
        self.physicsBody.dynamic = NO;

    }
    return self;
}
@end
