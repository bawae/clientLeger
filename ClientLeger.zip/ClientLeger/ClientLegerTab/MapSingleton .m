//
//  MapSingleton.m
//  ClientLegerTab
//
//  Singleton qui permet de determiner l'etat de la carte en cours d'edition
//  ainsi que la carte en cours de chargement
//  Created by Mouhamadou Oumar Sall on 21/11/2015.
//  Copyright (c) 2015 Mos. All rights reserved.
//

#import "MapSingleton.h"
#include <stdlib.h>

@implementation MapSingleton

static MapSingleton *sharedMapSingleton = nil;    // static instance variable
static dispatch_once_t pred;


/*!
 * @discussion Methode qui retourne l'instance du MapSingleton
 *
 * @return MapSingleton
 */
+ (MapSingleton *)sharedInstance {
    if (sharedMapSingleton == nil) {
        dispatch_once(&pred, ^{
            sharedMapSingleton = [[super allocWithZone:NULL] init];
            sharedMapSingleton->cardTitle = @"defaultCard";
            sharedMapSingleton->cardUser = @"GuestUser";
            sharedMapSingleton->cardId = @"GuestId";
            sharedMapSingleton->pbc = arc4random_uniform(5);
            sharedMapSingleton->pbt = arc4random_uniform(5);
            sharedMapSingleton->ppg = arc4random_uniform(5);
            sharedMapSingleton->pb = arc4random_uniform(5);
            sharedMapSingleton->pc = arc4random_uniform(5);
            sharedMapSingleton->cardDifficulty = 1;
        });
    }
    return sharedMapSingleton;
}


/*!
 * @discussion Setter pour le titre de la carte
 *
 * @param (NSString*) t
 */
- (void)setCardTitle:(NSString*)t {
    cardTitle = t;
}

/*!
 * @discussion Setter pour l'utilisateur de la carte
 *
 * @param (NSString*) u
 */
- (void)setCardUser:(NSString*)u {
    cardUser = u;
}

/*!
 * @discussion Setter pour l'id de la carte
 *
 * @param (NSString*) u
 */
- (void)setCardId:(NSString*)i {
    cardId = i;
}

/*!
 * @discussion Setter pour les points du butoir circulaire
 *
 * @param (NSInteger) p
 */
- (void)setCardpbcirculaire:(NSInteger)p {
    pbc = p;
}

/*!
 * @discussion Setter pour les points du butoir triangulaire
 *
 * @param (NSInteger) p
 */
- (void)setCardpbtriangulaire:(NSInteger)p {
    pbt = p;
}

/*!
 * @discussion Setter pour les points pour gagner
 *
 * @param (NSInteger) p
 */
- (void)setCardpgagner:(NSInteger)p {
    ppg=p;
}

/*!
 * @discussion Setter pour les points pour obtenir une bille
 *
 * @param (NSInteger) p
 */
- (void)setCardpbille:(NSInteger)p {
    pb = p;
}


/*!
 * @discussion Setter pour les points pour la cible
 *
 * @param (NSInteger) p
 */
- (void)setCardpcible:(NSInteger)p {
    pc = p;
}

/*!
 * @discussion Getter titre carte
 *
 * @return   */
- (NSString*)getCardTitle {
    return cardTitle;
}

/*!
 * @discussion Getter utilisateur carte
 *
 * @return   */
- (NSString*)getCardUser {
    return cardUser;
}

/*!
 * @discussion Getter card Id
 *
 * @return   */
- (NSString*)getCardId {
    return cardId;
    
}
/*!
 * @discussion Getter point Butoir circulaire
 *
 * @return   */
- (NSInteger)getCardpbcirculaire {
    return pbc;
}

/*!
 * @discussion Getter points butoir triangulaire
 *
 * @return   */
- (NSInteger)getCardpbtriangulaire {
    return pbt;
}

/*!
 * @discussion Getter point pour gagner
 *
 * @return
 */
- (NSInteger)getCardpgagner {
    return ppg;
}

/*!
 * @discussion Getter point bille
 *
 * @return
 */
- (NSInteger)getCardpbille {
    return pb;
}

/*!
 * @discussion Getter point pour cible
 *
 * @return
 */
- (NSInteger)getCardpcible {
    return pc;
}

/*!
 * @discussion Getter pour la difficulte de la carte
 *
 * @return
 */
- (NSInteger)getCardDifficulty {
    
    return cardDifficulty;
}

/*!
 * @discussion Setter pour la difficulte de la carte
 *
 * @return
 */
- (void)setCardDifficulty:(NSInteger)d {
    cardDifficulty = d;
}

@end


