//
//  FactoryNode.m
//  ClientLegerTab
//
// Creer differents type de noeuds dependant du parametre
//
//  Created by Mos on 03/11/2015.
//  Copyright (c) 2015 Mos. All rights reserved.
//
#import "FactoryNode.h"
#import "Constants.h"


@implementation FactoryNode


- (instancetype) init {
    
    return self;
}


/*!
 * @discussion Cree un noeud dependant du parametre du visiteur xml xml
 *
 * @param nodeType Le type de noeud que l'on desire creer
 * @param AbstractNode une instance du noeud
 */
- (AbstractNode*) createNode:(NSString*)nodeType {
    
    if([nodeType  isEqualToString:TYPE_TROU]) {
        NodeTrou* node = [NodeTrou new];
        return node;
    }
    
    if([nodeType  isEqual:TYPE_RESSORT]) {
        NodeRessort* node = [NodeRessort new];
        return node;
    }
    
    if([nodeType  isEqual:TYPE_PORTAIL]) {
        NodePortail* node = [NodePortail new];
        return node;
    }
    
    if([nodeType  isEqual:TYPE_GENERATEUR]) {
        NodeGenerateur* node = [NodeGenerateur new];
        return node;
    }
    
    if([nodeType  isEqual:TYPE_BUTOIRTRIANGULAIRER]) {
        NodeButoirTriangulaireR* node = [NodeButoirTriangulaireR new];
        return node;
    }
    
    if([nodeType  isEqual:TYPE_BUTOIRTRIANGULAIREL]) {
        NodeButoirTriangulaireL* node = [NodeButoirTriangulaireL new];
        return node;
    }
    
    if([nodeType  isEqual:TYPE_BUTOIRCIRCULAIRE]) {
        NodeButoirCirculaire* node = [NodeButoirCirculaire new];
        return node;
    }
    
    if([nodeType  isEqual:TYPE_MUR]) {
        NodeMur* node = [NodeMur new];
        return node;
    }
    
    if([nodeType  isEqual:TYPE_PALETTE1L]) {
        NodePalette1L* node = [NodePalette1L new];
        return node;
    }
    
    if([nodeType  isEqual:TYPE_PALETTE1R]) {
        NodePalette1R* node = [NodePalette1R new];
        return node;
    }
    
    if([nodeType  isEqual:TYPE_PALETTE2R]) {
        NodePalette2R* node = [NodePalette2R new];
        return node;
    }
    
    if([nodeType  isEqual:TYPE_PALETTE2L]) {
        NodePalette2L* node = [NodePalette2L new];
        return node;
    }
    
    if([nodeType  isEqual:TYPE_CIBLE]) {
        NodeCible* node = [NodeCible new];
        return node;
    }
    
    return nil;
}

@end