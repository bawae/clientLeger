//
//  VisitorXML.h
//  ClientLegerTab
//
//  Classe qui se charge de parcourir une scene et de
//  creer une representation xml des noeuds
//
//  Created by Mos on 03/11/2015.
//  Copyright (c) 2015 Mos. All rights reserved.
//

#import "VisitorXML.h"
#import "EditorScene.h"
#import "VisitorXML.h"
#import "Constants.h"
#import "MapSingleton.h"
#import "Utility.h"



@interface VisitorXML ()

@end

@implementation VisitorXML
- (instancetype) init {
    if (self = [super init]) {
        
    }
    return self;
}

/*!
 * @discussion Constructeur du visiteur xml xml
 *
 * @param doc Le document sur lequel le contenu de la scene sera ecrit
 * @param racine La racine du document
 */
- (instancetype) initWithDoc:(DDXMLDocument*)doc rootElem:(DDXMLElement*)racine {
    if (self = [super init]) {
        doc_ = doc;
        racine_ = racine;
        
    }
    return self;
}

/*!
 * @discussion Methode qui visite une scene afin de produire le document xml
 *
 * @param scene La scene à visiter
 */
- (void) visitS:(EditorScene*)scene {
    NSMutableArray* nodes = [[NSMutableArray alloc] init];
    nodes = [self getAllNodes:@"//*" from:scene];
    for (AbstractNode* node in nodes) {
        DDXMLElement* noeud = [[DDXMLElement alloc] initWithName:@"noeud" ];
        [racine_ addChild:noeud];
        DDXMLElement* type = [[DDXMLElement alloc] initWithName:@"Type" ];
        [noeud addChild:type];
        NSString* nodeName = node.name;
        if([nodeName containsString:@"NodePortail"]) {
            // Regex : exemple NodePortail_1
            NSArray *portailPart = [nodeName componentsSeparatedByString:@"_"];
            [type addAttribute:[DDXMLNode attributeWithName:@"id" stringValue:[self getNumIdNode:portailPart[0]]]];
            NSString* nodeRotation = [NSString stringWithFormat:@"%.2f", node.zRotation];
            [type addAttribute:[DDXMLNode attributeWithName:@"Rotation" stringValue:nodeRotation]];
            //Passer de l'anchorPoint (0,0) aux coordonnées OpenGL du client Lourd (-xPlus, -yPlus)
            NSString* nodePosition = [NSString stringWithFormat:@"%.2f %.2f 0.00",node.position.x - xPlus, node.position.y - yPlus];
            [type addAttribute:[DDXMLNode attributeWithName:@"Position" stringValue:nodePosition]];
            NSString* nodeScale = [NSString stringWithFormat:@"%.2f %.2f 1.00",node.xScale, node.yScale];
            [type addAttribute:[DDXMLNode attributeWithName:@"Scale" stringValue:nodeScale]];
            [type addAttribute:[DDXMLNode attributeWithName:@"PortalLink" stringValue:portailPart[1]]];
        }else{
            [type addAttribute:[DDXMLNode attributeWithName:@"id" stringValue:[self getNumIdNode:node.name]]];
            NSString* nodeRotation = [NSString stringWithFormat:@"%.2f",node.zRotation];
            [type addAttribute:[DDXMLNode attributeWithName:@"Rotation" stringValue:nodeRotation]];
            //Passer de l'anchorPoint (0,0) aux coordonnées OpenGL du client Lourd (-xPlus, -yPlus)
            NSString* nodePosition = [NSString stringWithFormat:@"%.2f %.2f 0.00",node.position.x - xPlus, node.position.y - yPlus];
            [type addAttribute:[DDXMLNode attributeWithName:@"Position" stringValue:nodePosition]];
            NSString* nodeScale = [NSString stringWithFormat:@"%.2f %.2f 1.00",node.xScale, node.yScale];
            [type addAttribute:[DDXMLNode attributeWithName:@"Scale" stringValue:nodeScale]];
        }
    }
    //Configuration
    DDXMLElement* configuration = [[DDXMLElement alloc] initWithName:@"Config" ];
    [racine_ addChild:configuration];
    DDXMLElement* point = [[DDXMLElement alloc] initWithName:@"Point" ];
    NSString* PtsBC = [NSString stringWithFormat: @"%ld", (long)[[MapSingleton sharedInstance] getCardpbcirculaire]];
    NSString* PtsBT = [NSString stringWithFormat: @"%ld", (long)[[MapSingleton sharedInstance] getCardpbtriangulaire]];
    NSString* PtsCible = [NSString stringWithFormat: @"%ld", (long)[[MapSingleton sharedInstance] getCardpcible]];
    NSString* PtsNewBall = [NSString stringWithFormat: @"%ld", (long)[[MapSingleton sharedInstance] getCardpbille]];
    NSString* PtsEndGame = [NSString stringWithFormat: @"%ld", (long)[[MapSingleton sharedInstance] getCardpgagner]];
    NSString* Difficulty = [NSString stringWithFormat: @"%ld", (long)[[MapSingleton sharedInstance] getCardDifficulty]];
    [point addAttribute:[DDXMLNode attributeWithName:@"PtsBC" stringValue:PtsBC]];
    [point addAttribute:[DDXMLNode attributeWithName:@"PtsBT" stringValue:PtsBT]];
    [point addAttribute:[DDXMLNode attributeWithName:@"PtsBT" stringValue:PtsBT]];
    [point addAttribute:[DDXMLNode attributeWithName:@"PtsCible" stringValue:PtsCible]];
    [point addAttribute:[DDXMLNode attributeWithName:@"PtsNewBall" stringValue:PtsNewBall]];
    [point addAttribute:[DDXMLNode attributeWithName:@"PtsEndGame" stringValue:PtsEndGame]];
    [point addAttribute:[DDXMLNode attributeWithName:@"Difficulty" stringValue:Difficulty]];
    
    [configuration addChild:point];
}

/*!
 * @discussion Methode qui retourne sous forme de texte le document
 * xml generer apres le parcours de la scene
 *
 * @return NSString
 */
- (NSString *) getString {
    NSData *xmlData = [doc_ XMLData];
    return [[NSString alloc]initWithData:xmlData encoding:NSUTF8StringEncoding];
}


/*!
 * @discussion Methode qui retourne le document xml generer apres le parcours de
 * la scene
 *
 * @return DDXMLDocument
 */
- (DDXMLDocument *) getXMLDocument {
    return doc_;
}

/*!
 * @discussion Methode qui retourne l'ensemble des noeuds specifiés par le parametre nodeName
 *
 * @param nodeName regex des noeuds à selectionner
 * @param table scene sur laquelle on cherche les noeuds
 * @return NSMutableArray l'ensemble des noeuds qui satisfassent les conditions
 */
- (NSMutableArray*) getAllNodes:(NSString*)nodeName from:(EditorScene*)table {
    NSMutableArray* arrayOfNodes = [[NSMutableArray alloc] init];
    [table enumerateChildNodesWithName:nodeName usingBlock:^(SKNode *node, BOOL *stop) {
        // Pas besoin de sauvegarder la table ainsi que les noeuds du Header(menu)
        if (![node.name isEqualToString:@"table"] && ![node.name containsString:@"Fixed"] && ![node.name isEqualToString:@"limit"] )
            [arrayOfNodes addObject:(AbstractNode*) node];
    }];
    return arrayOfNodes;
}



/*
 //Node id
 int const TYPE_RESSORT = 1;
 int const TYPE_TROU = 2;
 int const TYPE_PORTAIL = 3;
 int const TYPE_GENERATEUR = 4;
 int const TYPE_MUR = 5;
 int const TYPE_BUTOIRCIRCULAIRE = 6;
 int const TYPE_BUTOIRTRIANGULAIRER = 7;
 int const TYPE_BUTOIRTRIANGULAIREL = 8;
 int const TYPE_BTL = 9;  <--- unuseful
 int const TYPE_CIBLE = 10;
 int const TYPE_PALETTE1R = 11;
 int const TYPE_PALETTE2R = 12;
 int const TYPE_PALETTE1L = 13;
 int const TYPE_PALETTE2L = 14;
 int const TYPE_BILLE = 15;
 int const TYPE_ZONE = 19;
 */

- (NSString*) getNumIdNode:(NSString*)name {
    
    if([name  isEqual:NODE_RESSORT]) {
        return TYPE_RESSORT;
    }
    
    if([name  isEqual:NODE_TROU]) {
        return TYPE_TROU;
    }
    
    if([name  isEqual:NODE_PORTAIL]) {
        return TYPE_PORTAIL;
    }
    
    if([name  isEqual:NODE_GENERATEUR]) {
        return TYPE_GENERATEUR;
    }
    
    if([name  isEqual:NODE_MUR]) {
        return TYPE_MUR;
    }
    if([name  isEqual:NODE_BUTOIRCIRCULAIRE]) {
        return TYPE_BUTOIRCIRCULAIRE;
    }
    
    if([name  isEqual:NODE_BUTOIRTRIANGULAIRER]) {
        return TYPE_BUTOIRTRIANGULAIRER;
    }
    
    if([name  isEqual:NODE_BUTOIRTRIANGULAIREL]) {
        return TYPE_BUTOIRTRIANGULAIREL;
    }
    
    if([name  isEqual:NODE_PALETTE1R]) {
        return TYPE_PALETTE1R;
    }
    
    if([name  isEqual:NODE_PALETTE1L]) {
        return TYPE_PALETTE1L;
    }
    
    if([name  isEqual:NODE_PALETTE2R]) {
        return TYPE_PALETTE2R;
    }
    
    if([name  isEqual:NODE_PALETTE2L]) {
        return TYPE_PALETTE2L;
    }
    
    if([name  isEqual:NODE_PALETTE2L]) {
        return TYPE_PALETTE2L;
    }
    
    return @"0";
}
@end
