//
//  AudioSingleton.h
//  ClientLegerTab
//
//  Singleton qui permet de determiner l'etat de la carte en cours d'edition
//  ainsi que la carte en cours de chargement
//  Created by Mouhamadou Oumar Sall on 01/12/2015.
//  Copyright (c) 2015 Mos. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "AudioController.h"

@interface AudioSingleton : NSObject {
    AudioController* player;
}

+ (AudioSingleton *)sharedInstance;

- (void)playBackgroundSound;
- (void)stopBackgroundSound;
@end
