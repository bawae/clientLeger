//
//  CarteViewController.m
//  ClientLegerTab
//
//  Created by Mos on 16/11/2015.
//  Copyright (c) 2015 Mos. All rights reserved.
//


#import <UIKit/UIKit.h>
#import "iCarousel.h"

@interface CarteViewController : UIViewController <iCarouselDataSource, iCarouselDelegate>

@property (weak, nonatomic) IBOutlet iCarousel *caroussel;

@property (weak, nonatomic) IBOutlet UILabel *propioLabel;
@property (weak, nonatomic) IBOutlet UILabel *DifficulteLabel;
@property (weak, nonatomic) IBOutlet UILabel *pbcLabel;
@property (weak, nonatomic) IBOutlet UILabel *pbtLabel;
@property (weak, nonatomic) IBOutlet UILabel *pcLabel;
@property (weak, nonatomic) IBOutlet UILabel *pbLabel;
@property (weak, nonatomic) IBOutlet UILabel *ppg;

@end

