//
//  NodeBille.m
//  
//
//  Created by Mos on 19/10/2015.
//
//

#import <Foundation/Foundation.h>

#import "NodePalette1R.h"

@implementation NodePalette1R

- (instancetype) init {
    // note that [super init] will call the SpaceshipNode's init method
    if (self = [super init]) {
        NSLog(@"A new NodePalette1R was just init'ed.");
        self = (NodePalette1R*) [[SKSpriteNode alloc]initWithImageNamed:@"NodePalette1R"];
        self.name =@"NodePalette1R";
    }
    return self;
}

@end
