//
//  TabBarViewController.m
//  ClientLegerTab
//
//  Created by Mos on 16/11/2015.
//  Copyright (c) 2015 Mos. All rights reserved.
//

#import "TabBarViewController.h"
#import "SessionSingleton.h"
#import "Parse/Parse.h"
#import "Constants.h"

@interface TabBarViewController ()
@end

@implementation TabBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //[[self.viewControllers objectAtIndex:0] setTitle:NSLocalizedString(@"home", nil)];
    
   // [[self.viewControllers objectAtIndex:1] setTitle:NSLocalizedString(@"statistics", nil)];
    
   // [[self.viewControllers objectAtIndex:2] setTitle:NSLocalizedString(@"settings", nil)];
    
   // [[self.viewControllers objectAtIndex:3] setTitle:NSLocalizedString(@"info", nil)];
    
    UITabBarItem* editeur = [[UITabBarItem alloc]initWithTitle:@"Editeur" image:[UIImage imageNamed:@"design"] tag:0];
    [[self.viewControllers objectAtIndex:0] setTabBarItem:editeur];
    
    UITabBarItem* card = [[UITabBarItem alloc]initWithTitle:@"Cartes" image:[UIImage imageNamed:@"map"] tag:31];
    [[self.viewControllers objectAtIndex:1] setTabBarItem:card];
    
    UITabBarItem* profile = [[UITabBarItem alloc]initWithTitle:@"Profile" image:[UIImage imageNamed:@"user_male_circle"] tag:32];
    [[self.viewControllers objectAtIndex:2] setTabBarItem:profile];
    
    UITabBarItem* stats = [[UITabBarItem alloc]initWithTitle:@"Statistiques" image:[UIImage imageNamed:@"leaderboard"] tag:33];
    [[self.viewControllers objectAtIndex:3] setTabBarItem:stats];
    
}
@end
