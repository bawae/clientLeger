//
//  PageContentViewController.m
//  ClientLeger_
//
//  Classe qui contient la logique de l'edition
//
//  Created by Mouhamadou Oumar on 18/10/2015.
//  InspiredBy com.TheAppGuruz. All rights reserved.

#import "PageContentViewController.h"
#import "MapSingleton.h"
#import "Utility.h"
#import "FLAnimatedImage.h"
#import "FLAnimatedImageView.h"




@interface PageContentViewController ()

@end



@implementation PageContentViewController
@synthesize gifUrl, instructionText;

- (void)viewDidLoad {
    [super viewDidLoad];
        self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"backgroundPinBallProp"]];
    self.textView.text = self.instructionText;
    self.textView.backgroundColor = [UIColor clearColor];
    self.textView.font = [UIFont fontWithName:@"Noteworthy-Bold" size:16];
    
    [self.textView setTextColor:[UIColor colorWithRed:0.95 green:0.77 blue:0.06 alpha:1.0]];
    FLAnimatedImage *image = [FLAnimatedImage animatedImageWithGIFData:[NSData dataWithContentsOfURL:[NSURL URLWithString:self.gifUrl]]];
    FLAnimatedImageView *imageView = [[FLAnimatedImageView alloc] init];
    imageView.animatedImage = image;
    imageView.frame = CGRectMake(70, 30, 600.0, 700.0);
    [self.view addSubview:imageView];
  }

@end
