//
//  FactoryNode.h
//  ClientLegerTab
//
// Creer differents type de noeuds dependant du parametre
//
//  Created by Mos on 03/11/2015.
//  Copyright (c) 2015 Mos. All rights reserved.
//
#import <SpriteKit/SpriteKit.h>
#import <Foundation/Foundation.h>
#import "FactoryNode.h"
#import "AbstractNode.h"
#import "Constants.h"
#import "NodeHeader.h"


@interface FactoryNode : NSObject 
- (AbstractNode*) createNode:(NSString*)nodeType;
@end

