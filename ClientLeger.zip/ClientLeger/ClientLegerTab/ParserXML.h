//
//  ParserXML.h
//  ClientLegerTab
//
//  Classe qui se charge de lire une carte xml et peupler la scene
//  Created by Mos on 03/11/2015.
//  Copyright (c) 2015 Mos. All rights reserved.
//


#import <Foundation/Foundation.h>
#import "AbstractNode.h"
#import "DDXML.h"

@class EditorScene;


@interface ParserXML : NSObject {
    
    DDXMLDocument* doc_;
    
}

- (EditorScene*) getEditorScene:(DDXMLDocument*) doc;
- (instancetype) initWithDoc:(DDXMLDocument*)doc;
+ (AbstractNode*) getEditorScene:(DDXMLDocument*) doc;

@end