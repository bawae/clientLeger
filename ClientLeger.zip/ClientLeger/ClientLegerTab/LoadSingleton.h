//
//  MapSingleton.h
//  ClientLegerTab
//
//  Singleton qui permet de determiner l'etat de la carte en cours d'edition
//  ainsi que la carte en cours de chargement
//  Created by Mouhamadou Oumar Sall on 21/11/2015.
//  Copyright (c) 2015 Mos. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DDXML.h"

@interface LoadSingleton : NSObject {
    BOOL loadMode; // est a True lorsqu'on edite une carte charge
    DDXMLDocument* currentMap;// La carte chargee
}

+ (LoadSingleton *)sharedInstance;
- (void)setMode:(BOOL)b;
- (void)setCurrentMap:(DDXMLDocument*)doc;
- (BOOL)getMode;
- (DDXMLDocument*)getCurrentMap;
@end
