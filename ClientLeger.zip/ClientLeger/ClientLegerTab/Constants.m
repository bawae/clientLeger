//
//  Constant.h
//  ClientLegerTab
//
//  Cette classe regroupe les variables contantes utilisées dans le projet
//  Created by Mouhamadou Oumar Sall on 07/11/2015.
//  Copyright (c) 2015 Mos. All rights reserved.


#import "Constants.h"


//Node name
NSString * const NODE_TROU = @"NodeTrou";
NSString * const NODE_PORTAIL = @"NodePortail";
NSString * const NODE_BUTOIRCIRCULAIRE = @"NodeButoirCirculaire";
NSString * const NODE_BUTOIRTRIANGULAIREL = @"NodeButoirTriangulaireL";
NSString * const NODE_BUTOIRTRIANGULAIRER = @"NodeButoirTriangulaireR";
NSString * const NODE_GENERATEUR = @"NodeGenerateur";
NSString * const NODE_RESSORT = @"NodeRessort";
NSString * const NODE_PALETTE1R = @"NodePalette1R";
NSString * const NODE_PALETTE1L = @"NodePalette1L";
NSString * const NODE_PALETTE2R = @"NodePalette2R";
NSString * const NODE_PALETTE2L = @"NodePalette2L";
NSString * const NODE_TABLE = @"table";
NSString * const NODE_MUR = @"NodeMur";

//Carte
NSString * const PROP = @"Propriétaire : ";
NSString * const DIFF = @"Difficulté : ";
NSString * const PBC = @"Points Butoir Circulaire : ";
NSString * const PBT = @"Points Butoir Triangulaire : ";
NSString * const PPG = @"Points pour gagner : ";
NSString * const PB = @"Points bille : ";
NSString * const PC = @"Points cible : ";

//Node id
NSString * const TYPE_RACINE = @"0";
NSString * const TYPE_RESSORT = @"1";
NSString * const TYPE_TROU = @"2";
NSString * const TYPE_PORTAIL = @"3";
NSString * const TYPE_GENERATEUR = @"4";
NSString * const TYPE_MUR = @"5";
NSString * const TYPE_BUTOIRCIRCULAIRE = @"6";
NSString * const TYPE_BUTOIRTRIANGULAIRER = @"7";
NSString * const TYPE_BUTOIRTRIANGULAIREL = @"8";
NSString * const TYPE_BTL = @"9";
NSString * const TYPE_CIBLE = @"10";
NSString * const TYPE_PALETTE1R = @"11";
NSString * const TYPE_PALETTE2R = @"12";
NSString * const TYPE_PALETTE1L = @"13";
NSString * const TYPE_PALETTE2L = @"14";
NSString * const TYPE_BILLE = @"15";
NSString * const TYPE_ZONE = @"19";


//Parse
NSString * const PARSE_CARTE_CLASS = @"CarteTest";
NSString * const PARSE_USER_CLASS = @"Users";







