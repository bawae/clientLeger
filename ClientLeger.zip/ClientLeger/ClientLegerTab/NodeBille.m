//
//  NodeBille.m
//  
//
//  Created by Mos on 19/10/2015.
//
//

#import <Foundation/Foundation.h>

#import "NodeBille.h"

@implementation NodeBille

- (instancetype) init {
    // note that [super init] will call the SpaceshipNode's init method
    if (self = [super init]) {
        NSLog(@"A new NodeRessort was just init'ed.");
        self = (NodeBille*) [[SKSpriteNode alloc]initWithImageNamed:@"ball"];
        self.name =@"ball";
    }
    return self;
}

@end
