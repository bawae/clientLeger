//
//  SessionSingleton.h
//  ClientLegerTab
//
//  Singleton qui permet de determiner l'etat de la carte en cours d'edition
//  ainsi que la carte en cours de chargement
//  Created by Mouhamadou Oumar Sall on 21/11/2015.
//  Copyright (c) 2015 Mos. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "DDXML.h"

@interface SessionSingleton : NSObject {
    NSString* userName;
    NSString* userPassword;
    NSString* userEmail;
    @public NSString* nom;
    @public NSString* prenom;
    @public NSString* tempsJeu;
    @public NSString* pgagne;
    @public NSString* pperdue;
    @public NSString* highscore;
    @public UIImage* userPicProfile;
}

+ (SessionSingleton *)sharedInstance;
- (void)setUserName:(NSString*) name;
- (void)setUserEmail:(NSString*)email;
- (void)setUserPassword:(NSString*)password;
- (void)setUserPicure:(UIImage*)picture;
- (NSString*)getUsername;
- (NSString*)getUserEmail;
- (UIImage*)getUserPicture;
@end
