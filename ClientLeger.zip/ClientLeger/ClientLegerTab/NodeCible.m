//
//  NodeTrou.m
//  
//
//  Created by Mos on 19/10/2015.
//
//

#import <Foundation/Foundation.h>
#import "NodeCible.h"
#import "Constants.h"

@implementation NodeCible

- (instancetype) init {
    // note that [super init] will call the SpaceshipNode's init method
    if (self = [super init]) {
        NSLog(@"A new NodeCible was just init'ed.");
        self = (NodeCible*) [[SKSpriteNode alloc]initWithImageNamed:@"NodeCible"];
        self.name =@"NodeTrou";
        self.physicsBody = [SKPhysicsBody bodyWithCircleOfRadius:self.frame.size.width/2];
        self.physicsBody.categoryBitMask = NFIXEDCATEGORY;
        self.physicsBody.collisionBitMask = NFIXEDCATEGORY;
        self.physicsBody.dynamic = NO;
    }
    return self;
}
@end
