//
//  Utility.h
//  ClientLegerTab
//
//  Created by Mos on 07/11/2015.
//  Copyright (c) 2015 Mos. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

/** Degrees to Radian **/
#define degreesToRadians( degrees ) ( ( degrees ) / 180.0 * M_PI )

/** Radians to Degrees **/
#define radiansToDegrees( radians ) ( ( radians ) * ( 180.0 / M_PI ) )

@interface Utility : NSObject {
    
}

+ (UIImage *)imageWithImage:(UIImage *)image scaledToSize:(CGSize)newSize;
+ (NSString*) IntegerToString:(NSInteger)n;
+ (NSData*) XMLStringFormat:(NSData*) weakXML;
+ (UIImage *)scaleAndRotateImage:(UIImage *) image;
+ (float) RadtoDeg:(float )rad;
+ (float) degToRad:(float )degree;
@end
