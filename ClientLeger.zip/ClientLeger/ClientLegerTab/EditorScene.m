//
//  EditorScene.m
//  ClientLeger_
//
//  Classe qui contient la logique de l'edition
//  Created by Mouhamadou Oumar on 18/10/2015.
//  Copyright (c) 2015 mos. All rights reserved.
//

#import "EditorScene.h"
#import "EditorViewController.h"
#import "NodeHeader.h"
#import <Parse/Parse.h>
#import "ParserXML.h"
#import "LoadSingleton.h"
#import "SessionSingleton.h"
#import "MapSingleton.h"
#import <math.h>
#import "AudioController.h"

@import CoreGraphics;


@interface EditorScene ()

@property (nonatomic, strong) SKSpriteNode *table;
@property (nonatomic, strong) NSMutableArray *selectedNodes;
@property (nonatomic, strong) SKSpriteNode *selectedNode;
@property (nonatomic, strong) SKNode* centerNode;
@property (nonatomic) CGPoint centreRotation;
@property (nonatomic, strong) NSMutableArray* coordinatesBeforeRotation;
@property (nonatomic) CGFloat nouvPosX;
@property (nonatomic) CGFloat nouvPosY;
@property (nonatomic) AbstractNode* loadedTable;
@property (nonatomic) BOOL leftTouch;
@property (nonatomic) BOOL rightTouch;
@property (nonatomic) BOOL upTouch;
@property (nonatomic) BOOL downTouch;
@property (nonatomic) UITouch *touch;

@end
static BOOL rotateNode = TRUE;
static BOOL scaleNode = TRUE;
static int portailId = 0;

@implementation EditorScene
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    return YES;
}

+ (instancetype)sceneWithSize:(CGSize)size withFile:(DDXMLDocument*)doc {
    return [[self alloc] initWithSize:size withFile:doc];
}


-(instancetype)initWithSize:(CGSize)size withFile:(DDXMLDocument*)doc {
    if(self = [super initWithSize:size]) {
        _loadedTable = [ParserXML getEditorScene:doc];
    }
    NSLog(@"initWithSize:(CGSize)size withFile:");
    return self;
}


-(void)didMoveToView:(SKView *)view {
    //self.anchorPoint = CGPointMake(0.5, 0.5);
    [self setSize:CGSizeMake(390, 528)];
    MapSingleton* mapS = [MapSingleton sharedInstance];
    NSLog(@"DidMoveToview");
    //Initial Map setup
    _selectedNodes = [NSMutableArray new];
    _coordinatesBeforeRotation = [[NSMutableArray alloc]init];
    _table = [SKSpriteNode spriteNodeWithImageNamed:@"Background-1"];
    
    [_table setName:@"table"];
    [_table setAnchorPoint:self.anchorPoint];
    [self addChild:_table];
    [self createHeaderNode];
    // Lorsqu'on charge une carte
    if(_loadedTable != nil) {
        [_table addChild:_loadedTable];
        _loadedTable = nil;
    }
    self.physicsBody = [SKPhysicsBody bodyWithEdgeLoopFromRect:self.frame];
    //Initializing Gesture Recognizer
    UIPanGestureRecognizer *gestureRecognizer = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePanFrom:)];
    [[self view] addGestureRecognizer:gestureRecognizer];
    
    UIPinchGestureRecognizer *precog = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(handlePinch:)];
    [self.scene.view addGestureRecognizer:precog];
    precog.delegate = self;
    
    UIRotationGestureRecognizer *rotG = [[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(handleRotate:)];
    [self.scene.view addGestureRecognizer:rotG];
    rotG.delegate = self;
    
    UILongPressGestureRecognizer *lpgr
    = [[UILongPressGestureRecognizer alloc]
       initWithTarget:self action:@selector(handleLongPress:)];
    lpgr.delegate = self;
    lpgr.delaysTouchesBegan = YES;
    [self.scene.view addGestureRecognizer:lpgr];
}

-(void)update:(CFTimeInterval)currentTime {
	   
}


/*!
 * @discussion Methode qui crée le Toolbar des noeuds.
 *
 */
- (void)createHeaderNode {
    AbstractNode* nodePalette1L = [NodePalette1L new];
    int x1 = (self.size.width/13) * (1);
    int y1 = self.size.height - 25;
    nodePalette1L.name = @"NodePalette1L_Fixed";
    nodePalette1L.position = CGPointMake(x1, y1);
    nodePalette1L.xScale = 0.5;
    nodePalette1L.yScale = 0.5;
    [_table addChild:nodePalette1L];
    
    NodePalette1R* nodePalette1R = [NodePalette1R new];
    int x2 = (self.size.width/13) * (2);
    int y2 = self.size.height - 25;
    nodePalette1R.name = @"NodePalette1R_Fixed";
    nodePalette1R.position = CGPointMake(x2, y2);
    nodePalette1R.xScale = 0.5;
    nodePalette1R.yScale = 0.5;
    [_table addChild:nodePalette1R];
    
    NodePalette2L* nodePalette2L = [NodePalette2L new];
    int x3 = (self.size.width/13) * (3);
    int y3 = self.size.height - 25;
    nodePalette2L.name = @"NodePalette2L_Fixed";
    nodePalette2L.position = CGPointMake(x3, y3);
    nodePalette2L.xScale = 0.5;
    nodePalette2L.yScale = 0.5;
    [_table addChild:nodePalette2L];
    
    NodePalette2R* nodePalette2R = [NodePalette2R new];
    int x4 = (self.size.width/13) * (4);
    int y4= self.size.height - 25;
    nodePalette2R.name = @"NodePalette2R_Fixed";
    nodePalette2R.position = CGPointMake(x4, y4);
    nodePalette2R.xScale = 0.5;
    nodePalette2R.yScale = 0.5;
    [_table addChild:nodePalette2R];
    
    NodeRessort* nodeRessort = [NodeRessort new];
    int x5 = (self.size.width/13) * (5);
    int y5 = self.size.height - 25;
    nodeRessort.name = @"NodeRessort_Fixed";
    nodeRessort.position = CGPointMake(x5, y5);
    nodeRessort.xScale = 0.5;
    nodeRessort.yScale = 0.5;
    [_table addChild:nodeRessort];
    
    NodeButoirCirculaire* nodeButoirCirculaire = [NodeButoirCirculaire new];
    int x6 = (self.size.width/13) * (6);
    int y6 = self.size.height - 25;
    nodeButoirCirculaire.name = @"NodeButoirCirculaire_Fixed";
    nodeButoirCirculaire.position = CGPointMake(x6, y6);
    nodeButoirCirculaire.xScale = 0.5;
    nodeButoirCirculaire.yScale = 0.5;
    [_table addChild:nodeButoirCirculaire];
    
    NodeButoirTriangulaireL* nodeTriangulaireL = [NodeButoirTriangulaireL new];
    int x7 = (self.size.width/13) * (7);
    int y7 = self.size.height - 25;
    nodeTriangulaireL.name = @"NodeButoirTriangulaireL_Fixed";
    nodeTriangulaireL.position = CGPointMake(x7, y7);
    nodeTriangulaireL.xScale = 0.5;
    nodeTriangulaireL.yScale = 0.5;
    [_table addChild:nodeTriangulaireL];
    
    NodeButoirTriangulaireR* nodeTriangulaireR = [NodeButoirTriangulaireR new];
    int x8 = (self.size.width/13) * (8);
    int y8 = self.size.height - 25;
    nodeTriangulaireR.name = @"NodeButoirTriangulaireR_Fixed";
    nodeTriangulaireR.position = CGPointMake(x8, y8);
    nodeTriangulaireR.xScale = 0.5;
    nodeTriangulaireR.yScale = 0.5;
    [_table addChild:nodeTriangulaireR];
    
    NodeTrou* nodeTrou = [NodeTrou new];
    int x9 = (self.size.width/13) * (9);
    int y9 = self.size.height - 25;
    nodeTrou.name = @"NodeTrou_Fixed";
    nodeTrou.position = CGPointMake(x9, y9);
    nodeTrou.xScale = 0.5;
    nodeTrou.yScale = 0.5;
    [_table addChild:nodeTrou];
    
    NodePortail* nodePortail= [NodePortail new];
    int x10 = (self.size.width/13) * (10);
    int y10 = self.size.height - 25;
    nodePortail.name = @"NodePortail_Fixed";
    nodePortail.position = CGPointMake(x10, y10);
    nodePortail.xScale = 0.5;
    nodePortail.yScale = 0.5;
    [_table addChild:nodePortail];
    
    NodeGenerateur* nodeGenerateur= [NodeGenerateur new];
    int x11 = (self.size.width/13) * (11);
    int y11 = self.size.height - 25;
    nodeGenerateur.name = @"NodeGenerateur_Fixed";
    nodeGenerateur.position = CGPointMake(x11, y11);
    nodeGenerateur.xScale = 0.5;
    nodeGenerateur.yScale = 0.5;
    [_table addChild:nodeGenerateur];
    
    NodeMur* nodeMur= [NodeMur new];
    int x12 = (self.size.width/13) * (12);
    int y12 = self.size.height - 25;
    nodeMur.name = @"NodeMur_Fixed";
    nodeMur.position = CGPointMake(x12, y12);
    nodeMur.xScale = 0.5;
    nodeMur.yScale = 0.5;
    [_table addChild:nodeMur];
    
    // Ligne de delimitations
    [self drawLineU];
    [self drawLineB];
    [self drawLineL];
    [self drawLineR];
    
}


/*!
 * @discussion Methode qui dessine le trait de séparation entre le Toolbar des noeuds.
 * et la zone d'edition
 *
 */

-(void) drawLineU {
    SKShapeNode *yourline = [SKShapeNode node];
    CGMutablePathRef pathToDraw = CGPathCreateMutable();
    CGPathMoveToPoint(pathToDraw, NULL, 10, self.size.height - 50);
    CGPathAddLineToPoint(pathToDraw, NULL, self.size.width-10, self.size.height - 50);
    // CGPathMoveToPoint(pathToDraw, NULL, (-self.size.width/2.0 + 30), self.size.height/2.0 - 50.0);
    //CGPathAddLineToPoint(pathToDraw, NULL, self.size.width/2.0 - 30, self.size.height/2.0 - 50.0);
    yourline.path = pathToDraw;
    [yourline setStrokeColor:[UIColor blackColor]];
    // yourline.physicsBody = [SKPhysicsBody bodyWithEdgeFromPoint:CGPointMake(0, self.size.height - 100) toPoint:CGPointMake(self.size.width, self.size.height - 100)];
    self.physicsBody.collisionBitMask = 0x01 <<1;
    yourline.name = @"limit";
    [self addChild:yourline];
}


/*!
 * @discussion Methode qui dessine le trait de séparation Right
 *
 */
-(void) drawLineR {
    SKShapeNode *yourline = [SKShapeNode node];
    CGMutablePathRef pathToDraw = CGPathCreateMutable();
    CGPathMoveToPoint(pathToDraw, NULL, self.size.width-10, 50);
    CGPathAddLineToPoint(pathToDraw, NULL, self.size.width-10, self.size.height - 50);
    // CGPathMoveToPoint(pathToDraw, NULL, (self.size.width/2.0 - 30), self.size.height/2.0 - 50.0);
    //CGPathAddLineToPoint(pathToDraw, NULL, self.size.width/2.0 - 30, -self.size.height/2.0 + 50.0);
    yourline.path = pathToDraw;
    [yourline setStrokeColor:[UIColor blackColor]];
    // yourline.physicsBody = [SKPhysicsBody bodyWithEdgeFromPoint:CGPointMake(0, self.size.height - 100) toPoint:CGPointMake(self.size.width, self.size.height - 100)];
    self.physicsBody.collisionBitMask = 0x01 <<1;
    yourline.name = @"limit";
    [self addChild:yourline];
}

/*!
 * @discussion Methode qui dessine le trait de séparation Left
 *
 */

-(void) drawLineL {
    SKShapeNode *yourline = [SKShapeNode node];
    CGMutablePathRef pathToDraw = CGPathCreateMutable();
    CGPathMoveToPoint(pathToDraw, NULL, 10, self.size.height - 50);
    CGPathAddLineToPoint(pathToDraw, NULL, 10, 50);
    //CGPathMoveToPoint(pathToDraw, NULL, (-self.size.width/2.0 + 30), self.size.height/2.0 - 50.0);
    //CGPathAddLineToPoint(pathToDraw, NULL, -self.size.width/2.0 + 30, -self.size.height/2.0 + 50.0);
    yourline.path = pathToDraw;
    [yourline setStrokeColor:[UIColor blackColor]];
    // yourline.physicsBody = [SKPhysicsBody bodyWithEdgeFromPoint:CGPointMake(0, self.size.height - 100) toPoint:CGPointMake(self.size.width, self.size.height - 100)];
    self.physicsBody.collisionBitMask = 0x01 <<1;
    yourline.name = @"limit";
    [self addChild:yourline];
}

/*!
 * @discussion Methode qui dessine le trait de séparation Bottom
 *
 */
-(void) drawLineB {
    SKShapeNode *yourline = [SKShapeNode node];
    CGMutablePathRef pathToDraw = CGPathCreateMutable();
    CGPathMoveToPoint(pathToDraw, NULL, 10,  50);
    CGPathAddLineToPoint(pathToDraw, NULL, self.size.width-10, 50);
    //CGPathMoveToPoint(pathToDraw, NULL, (-self.size.width/2.0 + 30), -self.size.height/2.0 + 50.0);
    //CGPathAddLineToPoint(pathToDraw, NULL, self.size.width/2.0 - 30, -self.size.height/2.0 + 50.0);
    yourline.path = pathToDraw;
    [yourline setStrokeColor:[UIColor blackColor]];
    // yourline.physicsBody = [SKPhysicsBody bodyWithEdgeFromPoint:CGPointMake(0, self.size.height - 100) toPoint:CGPointMake(self.size.width, self.size.height - 100)];
    self.physicsBody.collisionBitMask = 0x01 <<1;
    yourline.name = @"limit";
    [self addChild:yourline];
}




/*!
 * @discussion Methode qui effectue la multiplication de deux points.
 *
 * @param v
 * @param s
 * @return v*s
 */
CGPoint mult(const CGPoint v, const CGFloat s) {
    return CGPointMake(v.x*s, v.y*s);
}


/*!
 * @discussion Méthode qui gere la logique de la sélection d'un noeud de la scene.
 * @param touchLocation La position que l'on a cliqué
 * @param secondNumber The second half of the equation.
 * @return The sum of the two numbers passed in.
 */
- (void)selectNodeForTouch:(CGPoint)touchLocation {
    SKSpriteNode *touchedNode = (SKSpriteNode *)[self nodeAtPoint:touchLocation];
    // Si le noeud touché est la table ou les noeuds du menu
    if ([touchedNode.name isEqualToString:@"table"] || [touchedNode.name containsString:@"Fixed"]) {
        
        for (AbstractNode* node in _selectedNodes) {
            [self unHighlightNode:node];
        }
        [_selectedNodes removeAllObjects];
        
    }else{
        if(![[touchedNode name] containsString:@"Fixed"]) {
            
            if(![_selectedNodes containsObject:touchedNode]) {
                
                [_selectedNodes addObject:touchedNode ];
                [self highlightNode:(AbstractNode*)touchedNode];
                
            }else if([_selectedNodes containsObject:touchedNode]) {
                
                [_selectedNodes removeObject:touchedNode];
                [self unHighlightNode:(AbstractNode*)touchedNode];
                
            }
        }
    }
}


/*!
 * @discussion Méthode qui est appelée lorsqu'on sélectionne un noeud de la scene.
 * @param touchLocation La position que l'on a cliqué
 * @param secondNumber The second half of the equation.
 * @return The sum of the two numbers passed in.
 */
- (void)selectNodeForFirstTouch:(CGPoint)touchLocation {
    //1
    SKSpriteNode *touchedNode = (SKSpriteNode *)[self nodeAtPoint:touchLocation];
    
    if ([touchedNode.name isEqualToString:@"table"] || [touchedNode.name containsString:@"Fixed"]) {
        for (AbstractNode* node in _selectedNodes) {
            [self unHighlightNode:node];
        }
        [_selectedNodes removeAllObjects];
    }else{
        if([_selectedNodes containsObject:touchedNode]) {
            [_selectedNodes removeObject:touchedNode ];
            [self unHighlightNode:(AbstractNode*)touchedNode];
        }else{
            [_selectedNodes addObject:touchedNode ];
            [self highlightNode:(AbstractNode*)touchedNode];
        }
    }
}


#pragma mark -
#pragma mark Action sheet Handler methods

/*!
 * @discussion Méthode qui est appelée lorsqu'on enregistre une carte ou
 * qu'on supprime un noeud.
 */
- (void) actionSheet:(UIActionSheet *) actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex {
    SKSpriteNode* newNode;
    
    // Carte action Sheet
    switch (actionSheet.tag) {
        case 0:
            switch (buttonIndex) {
                case 0: {           // Enregistrer
                    NSString* currentUser = [[SessionSingleton sharedInstance]getUsername];
                    NSString* mapUSer = [[MapSingleton sharedInstance] getCardUser];
                    
                    // si user different
                    // message erreur
                    if(![currentUser isEqualToString:mapUSer]){
                        UIAlertView* alert = [[UIAlertView alloc] initWithTitle: @"Erreur acces" message: @"Vous ne pouvez pas modifer une carte autre que la votre" delegate: self cancelButtonTitle: @"Annuler" otherButtonTitles: @"OK", nil];
                        [alert setTag:10];
                        [alert show];
                        //return;
                    }else{ // si même user ou carte non verouille save
                        NSString* cardTitle = [[MapSingleton sharedInstance] getCardTitle];
                        NSString* cardId = [[MapSingleton sharedInstance] getCardId];
                        DDXMLDocument* xmlDoc = [[DDXMLDocument alloc]initWithXMLString:@"<root/>" options:0 error:nil];
                        DDXMLElement* xml_root = [xmlDoc rootElement];
                        VisitorXML* vXml = [[VisitorXML alloc] initWithDoc:xmlDoc rootElem:xml_root];
                        [vXml visitS:self];
                        NSLog(@"LOG: Sauvegarde update XML, %@",[vXml getString]);
                        NSString* xmlString = [vXml getString];
                        xmlString = [xmlString stringByReplacingOccurrencesOfString:@"<root>"
                                                                         withString:@""];
                        xmlString = [xmlString stringByReplacingOccurrencesOfString:@"</root>"
                                                                         withString:@""];
                        xmlString = [xmlString stringByReplacingOccurrencesOfString:@"<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                                                                         withString:@""];
                        
                        
                        NSData* cardData=[xmlString dataUsingEncoding:NSUTF8StringEncoding];
                        NSString* cardName = [NSString stringWithFormat:@"%@.xml",cardTitle];
                        PFFile* cardFile = [PFFile fileWithName:cardName data:cardData];
                        [cardFile saveInBackground];
                        UIImage* cardPicture = [self sceneCapture];
                        NSData* imageData=UIImagePNGRepresentation(cardPicture);
                        PFFile *imageFile = [PFFile fileWithName:@"image.png" data:imageData];
                        [imageFile saveInBackground];
                        NSLog(@"LOG: Sauvegarde Carte, Saving Done !");
                        // Upadting carte
                        PFQuery *query = [PFQuery queryWithClassName:PARSE_CARTE_CLASS];
                        
                                                [query getObjectInBackgroundWithId:cardId
                                                     block:^(PFObject *carteObject, NSError *error) {
                                                         //User profile
                                                         carteObject[@"cardXML"] = cardFile;
                                                         carteObject[@"cardPicture"] = imageFile;                                                 [carteObject saveInBackground];
                                                     }];
           
                    }
                }
                    break;
                    
                    
                case 1: {           // Enregistrer sous
                    NSLog(@"Saving card");
                    UIAlertView *alertCardTitle = [[UIAlertView alloc] initWithTitle:@"Entrez le nom de la carte"
                                                                             message:@"  "
                                                                            delegate:self
                                                                   cancelButtonTitle:@"Annuler"
                                                                   otherButtonTitles:@"Enregistrer", nil];
                    alertCardTitle.alertViewStyle = UIAlertViewStylePlainTextInput;
                    [alertCardTitle show];
                    
                }
                    break;
                    
            }
            break;
            
            //Noeud action Sheet
        case 1:
            switch (buttonIndex) {
                case 0: // Supprimer
                    for (AbstractNode* node in  _selectedNodes) {
                        [node removeFromParent];
                    }
                    break;
                case 1: // Duppliquer
                    for (AbstractNode* node in  _selectedNodes) {
                        
                        if([node.name containsString:@"NodePortail"]){
                            NSString* nodePortail = node.name;
                            int pair =0;
                            for (AbstractNode* node in  _selectedNodes){
                                if([node.name isEqualToString:nodePortail]){
                                    pair++;
                                }
                            }
                            if (pair >= 2 && fmod(pair,2)==0){
                                portailId++;
                                newNode = [SKSpriteNode spriteNodeWithImageNamed:@"NodePortail"];
                                newNode.position = CGPointMake(node.position.x + 10, node.position.y);
                                NSString* basiNodeName = @"NodePortail";
                                newNode.name = [NSString stringWithFormat:@"%@_%d", basiNodeName, portailId];
                                newNode.name = node.name;
                                newNode.zRotation = node.zRotation;
                                newNode.xScale = node.xScale;
                                newNode.yScale = node.yScale;
                                [_table addChild:newNode];
                            }
                        }else{
                            newNode = [SKSpriteNode spriteNodeWithImageNamed:node.name];
                            newNode.position = CGPointMake(node.position.x + 10, node.position.y);
                            newNode.name = node.name;
                            newNode.zRotation = node.zRotation;
                            newNode.xScale = node.xScale;
                            newNode.yScale = node.yScale;
                            [_table addChild:newNode];
                        }
                    }
                    break;
                case 2: // Rotation
                    scaleNode =FALSE;
                    rotateNode = TRUE;
                    break;
                case 3: // Scale
                    scaleNode =TRUE;
                    rotateNode = FALSE;
                    break;
                case 4: // Scale + Rotate
                    scaleNode =TRUE;
                    rotateNode = TRUE;
                    break;
            }
            break;
            case 10:
            break;
    }
}

/*!
 * @discussion Méthode qui est appelée Lorsqu'on sauvegarde une carte ( apres avoir entré le nom de la carte à sauvegarder)
 */
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(alertView.tag != 10){ // tag 10 erreur sauvegarde
        if (buttonIndex == 1) {
            NSString* cardTitle = [alertView textFieldAtIndex:0].text;
            DDXMLDocument* xmlDoc = [[DDXMLDocument alloc]initWithXMLString:@"<root/>" options:0 error:nil];
            DDXMLElement* xml_root = [xmlDoc rootElement];
            VisitorXML* vXml = [[VisitorXML alloc] initWithDoc:xmlDoc rootElem:xml_root];
            [vXml visitS:self];
            NSLog(@"LOG: Sauvegarde XML, %@",[vXml getString]);
            NSString* xmlString = [vXml getString];
            xmlString = [xmlString stringByReplacingOccurrencesOfString:@"<root>"
                                                             withString:@""];
            xmlString = [xmlString stringByReplacingOccurrencesOfString:@"</root>"
                                                             withString:@""];
            xmlString = [xmlString stringByReplacingOccurrencesOfString:@"<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                                                             withString:@""];
            
            
            NSData* cardData=[xmlString dataUsingEncoding:NSUTF8StringEncoding];
            NSString* cardName = [NSString stringWithFormat:@"%@.xml",cardTitle];
            PFFile* cardFile = [PFFile fileWithName:cardName data:cardData];
            
            UIImage* cardPicture = [self sceneCapture];
            NSData* imageData=UIImagePNGRepresentation(cardPicture);
            PFFile *imageFile = [PFFile fileWithName:@"image.png" data:imageData];
            
            PFObject *carteObject = [PFObject objectWithClassName:PARSE_CARTE_CLASS];
            
            //TODO: Personnaliser user et parametre carte
            
            NSString* username = [[SessionSingleton sharedInstance]getUsername];
            if(username == nil)
                username = @"Invite";
            carteObject[@"user"] = username;
            carteObject[@"name"] = cardTitle;
            carteObject[@"cardXML"] = cardFile;
            carteObject[@"cardPicture"] = imageFile;
            [carteObject saveInBackground];
            NSLog(@"LOG: Sauvegarde Carte, Saving Done !");
        }
    }
}


#pragma mark -
#pragma mark Gesture Handler methods

/*!
 * @discussion Méthode qui gére la translation des noeuds.
 * @param translation translation à appliquer aux noeuds sélectionnés
 */
- (void)panForTranslation:(CGPoint)translation {

    for (AbstractNode* node in _selectedNodes) {
        CGPoint position = [node position];
        if(![[node name] containsString:@"Fixed"]) {
            CGSize boundary = self.size;
            // On s'assure d'etre dans la zone d'edition
            // TODO(Mos): Le cas lorsque plusieurs noeud sont selectionnees  ne fonctionnnent pas comme il faut
            //Noeud Mur
            if([node.name isEqualToString:@"NodeMur"]) {
                CGFloat minXTemp = CGRectGetMinX(node.frame);
                CGFloat maxXTemp = CGRectGetMaxX(node.frame);
                CGFloat minYTemp = CGRectGetMinY(node.frame);
                CGFloat maxYTemp = CGRectGetMaxY(node.frame);
                CGPoint tempPositionMin = CGPointMake(minXTemp + translation.x, minYTemp + translation.y);
                CGPoint tempPositionMax = CGPointMake(maxXTemp + translation.x, maxYTemp + translation.y);
                CGPoint tempPosition = CGPointMake(position.x + translation.x, position.y + translation.y);
                if ((([self containsPoint:tempPositionMin] && [self containsPoint:tempPositionMax] && [self containsPoint:tempPosition]) || (tempPosition.y > self.size.height - 50 && tempPosition.y < self.size.height) )) {
                    [node setPosition:tempPosition];
                }else
                    continue;
                
            }else{ // Pas Noeud Mur
                CGPoint tempPosition = CGPointMake(position.x + translation.x, position.y + translation.y);
                if ([self containsPoint:tempPosition] /*|| (tempPosition.y >self.size.height - 130 )*/ ) {
                    [node setPosition:tempPosition /*CGPointMake(position.x + translation.x, position.y + translation.y)*/];
                    
                }else
                    continue;
                
            }
        }
    }
}

/*!
 * @discussion Méthode qui est appelée lorsqu'on fait un drag d'un noeud
 * @param recognizer le recognizer qui détecte le drag
 */
- (void)handlePanFrom:(UIPanGestureRecognizer *)recognizer {
    if (recognizer.state == UIGestureRecognizerStateBegan) {
        CGPoint touchLocation = [recognizer locationInView:recognizer.view];
        touchLocation = [self convertPointFromView:touchLocation];
        SKSpriteNode *touchedNode = (SKSpriteNode *)[self nodeAtPoint:touchLocation];
        
        if([touchedNode.name containsString:@"Fixed"]) {
            NSArray *arrayName = [touchedNode.name componentsSeparatedByString:@"_"];
            NSString* nodeName = arrayName[0];
            
            if([nodeName isEqualToString:@"NodePortail"]) {
                portailId++;
                SKSpriteNode* node1 = [SKSpriteNode spriteNodeWithImageNamed:nodeName];
                node1.position = CGPointMake(touchLocation.x - 30, touchLocation.y);
                NSString* basiNodeName = nodeName;
                node1.name = [NSString stringWithFormat:@"%@_%d", basiNodeName, portailId];
                [_table addChild:node1];
                
                SKSpriteNode* node2 = [SKSpriteNode spriteNodeWithImageNamed:nodeName];
                node2.position = CGPointMake(touchLocation.x + 30, touchLocation.y);
                node2.name = node1.name = [NSString stringWithFormat:@"%@_%d", basiNodeName, portailId];
                [_table addChild:node2];
                
                [_selectedNodes addObject:node1];
                [_selectedNodes addObject:node2];
                [self highlightNode:node1];
                [self highlightNode:node2];
                
                
            }else{
                SKSpriteNode* node = [SKSpriteNode spriteNodeWithImageNamed:nodeName];
                node.position = touchLocation;
                node.name = nodeName;
                [_table addChild:node];
                [self selectNodeForTouch:touchLocation];
                
            }
            
        }
        
    } else if (recognizer.state == UIGestureRecognizerStateChanged) {
        
        CGPoint translation = [recognizer translationInView:recognizer.view];
        translation = CGPointMake(translation.x, -translation.y);
        [self panForTranslation:translation];
        [recognizer setTranslation:CGPointZero inView:recognizer.view];
        
    } else if (recognizer.state == UIGestureRecognizerStateEnded) {
        //if (![[_selectedNode name] containsString:kMovableNode]) {
        float scrollDuration = 0.2;
        CGPoint velocity = [recognizer velocityInView:recognizer.view];
        CGPoint pos = [_selectedNode position];
        CGPoint p = mult(velocity, scrollDuration);
        
        CGPoint newPos = CGPointMake(pos.x + p.x, pos.y + p.y);
        //newPos = [self boundLayerPos:newPos];
        [_selectedNode removeAllActions];
        // }
    }
}


- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    
    _touch = [touches anyObject];
    CGPoint touchLocation = [_touch locationInNode:self];
    SKNode *touchedNode = [self nodeAtPoint:touchLocation];
    
    if ( [_touch tapCount] == 1) {
        NSLog(@"%@ has been touched. Single tap.",touchedNode.name);
        NSLog(@"Scalex = %f",touchedNode.xScale);
        NSLog(@"Scaley = %f",touchedNode.yScale);
        NSLog(@"rotation = %f",touchedNode.zRotation);
        NSLog(@"height = %f",touchedNode.frame.size.height);
        NSLog(@"width = %f",touchedNode.frame.size.width);
        NSLog(@"positionX = %f",touchedNode.position.x);
        NSLog(@"positionY = %f",touchedNode.position.y);
        if([[touchedNode name] isEqualToString:@"NodeMur"]) {
            
            NSLog(@"minX = %f", CGRectGetMinX(touchedNode.frame));
            NSLog(@"maxX = %f",CGRectGetMaxX(touchedNode.frame));
            NSLog(@"minY = %f",CGRectGetMinY(touchedNode.frame));
            NSLog(@"maxY = %f",CGRectGetMaxY(touchedNode.frame));
        }
        
        SKSpriteNode *touchedNode = (SKSpriteNode *)[self nodeAtPoint:touchLocation];
        if ([touchedNode.name containsString:@"Fixed"]) {
            
            AudioController* evc = [[AudioController alloc]init];
            [evc  playSystemSound];
            for (AbstractNode* node in _selectedNodes) {
                [self unHighlightNode:node];
            }
            [_selectedNodes removeAllObjects];
        }
        
    } else if ( [_touch tapCount] == 2) {
        NSLog(@"%@ has been touched. Double tap.",touchedNode.name);
        [self selectNodeForTouch:touchLocation];
        
    }else if([_touch tapCount] == 3) {
        NSLog(@"%@ has been touched. Triple tap.",touchedNode.name);
        NSString *actionSheetTitle = @"Action Sheet Demo";
        NSString *destructiveTitle = @"Supprimer";
        NSString *duplicateTitle = @"Duppliquer";
        NSString *rotateTitle = @"Mode Rotation";
        NSString *scaleTitle = @"Mode Rotation + Mis à echelle";
        NSString *cancelTitle = @"Annuler";
        UIActionSheet *actionSheet = [[UIActionSheet alloc]
                                      initWithTitle:actionSheetTitle
                                      delegate:self
                                      cancelButtonTitle:cancelTitle
                                      destructiveButtonTitle:destructiveTitle
                                      otherButtonTitles:duplicateTitle, rotateTitle, scaleTitle, nil];
        
        
        [actionSheet setTag: 1];
        [actionSheet showInView:self.view];
    }

}


- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    //Two fingers touchs
    if ([touches count] == 2) {
        NSLog(@"Two fingers touch.");
        NSString *actionSheetTitle = @"Sauvegarde carte"; //Action Sheet Title
        NSString *saveTitle = @"Enregister";
        NSString *saveUnderTitle = @"Enregister carte sous";
        NSString *cancelTitle = @"Annuler";
        UIActionSheet *actionSheetSave = [[UIActionSheet alloc]
                                          initWithTitle:actionSheetTitle
                                          delegate:self
                                          cancelButtonTitle:cancelTitle
                                          destructiveButtonTitle:nil
                                          otherButtonTitles:saveTitle,saveUnderTitle, nil];
        
        [actionSheetSave setTag: 0];
        [actionSheetSave showInView:self.view];
    }
    
}

/*!
 * @discussion Méthode qui est appelée lorsqu'on effectue un "PinchGesture".
 * @param recognizer le recognizer qui détecte le Pinch
 */
- (void)handlePinch:(UIPinchGestureRecognizer *) recognizer
{
    if(scaleNode){
        NSLog(@"Scaling Pinch %f", recognizer.scale);
        SKAction *scale = [SKAction scaleBy:recognizer.scale duration:0];
        SKAction *scaleHeight = [SKAction scaleXBy:recognizer.scale y:1 duration:0];
        for(AbstractNode* node in _selectedNodes) {
            if([node.name isEqualToString:@"NodeMur"]) {
                if(node.xScale >6.5) {
                    node.xScale = 6.4;
                }else if(node.xScale < 0.5) {
                    node.xScale  = 0.51;
                }else{
                    SKAction *scaleHeight = [SKAction scaleXBy:recognizer.scale y:1 duration:0];
                    [node runAction:scaleHeight];
                }
            }
            else if (![node.name containsString:@"NodePalette"] && ![node.name isEqualToString:@"NodeRessort"]) {
                // Eviter une mise a l'echelle trop grande ou trop petite
                if(node.xScale > 3) {
                    node.xScale = 3;
                    node.yScale = 3;
                }else if(node.xScale <0.5) {
                    node.xScale  = 0.51;
                    node.yScale  = 0.51;
                }else{
                    SKAction *scale = [SKAction scaleBy:recognizer.scale duration:0];
                    [node runAction:scale];
                }
            }
        }
        recognizer.scale = 1;
    }
}



/*!
 * @discussion Méthode qui est appelée lorsqu'on effectue un "RotateGesture".
 * @param recognizer le recognizer qui détecte le RotateGesture
 */
- (void)handleRotate:(UIRotationGestureRecognizer *)recognizer
{
    if(rotateNode){
    
        NSLog(@"handleRotate");
        // Rotation de plusieurs noeuds
        if([_selectedNodes count] > 1) {
            CGFloat x = 0;
            CGFloat y = 0;
            if(recognizer.state == UIGestureRecognizerStateBegan)
            {    NSLog(@"UIGestureRecognizerStateBegan");
                
                for(int i = 0; i < [_selectedNodes count]; i++)
                {
                    x = x + [[_selectedNodes objectAtIndex:i] position].x;
                    y = y + [[_selectedNodes objectAtIndex:i] position].y;
                }
                _centreRotation = CGPointMake(x/[_selectedNodes count], y/[_selectedNodes count]);
                
                for(int i = 0; i < [_selectedNodes count]; i++)
                {
                    CGPoint pt = CGPointMake([[_selectedNodes objectAtIndex:i] position].x, [[_selectedNodes objectAtIndex:i] position].y);
                    
                    [_coordinatesBeforeRotation addObject:[NSValue valueWithCGPoint:pt]];
                }}
            if(recognizer.state == UIGestureRecognizerStateChanged)
            {
                NSLog(@"UIGestureRecognizerStateChanged");
                double angle = 0;
                CGPoint firstTouch =[recognizer locationOfTouch:0 inView:self.view];
                if(recognizer.numberOfTouches == 2){
                    CGPoint secondTouch =[recognizer locationOfTouch:1 inView:self.view];
                    angle = -(atan2(secondTouch.y - firstTouch.y, secondTouch.x - firstTouch.x) * 180 / M_PI);
                }
                
                if ([self allInside]) {
                    for(int i = 0; i < [_selectedNodes count]; i++)
                    {
                        CGPoint initialPoint = [[_coordinatesBeforeRotation objectAtIndex:i] CGPointValue];
                        _nouvPosX = cos(degToRad(angle))*(initialPoint.x - _centreRotation.x) - sin(degToRad(angle))*(initialPoint.y - _centreRotation.y) + _centreRotation.x;
                        _nouvPosY = sin(degToRad(angle))*(initialPoint.x - _centreRotation.x) + cos(degToRad(angle))*(initialPoint.y - _centreRotation.y) + _centreRotation.y;
                        
                        //CGPoint tempPosition = CGPointMake(_nouvPosX, _nouvPosY);
                        // if([self containsPoint:tempPosition])
                        [[_selectedNodes objectAtIndex:i] setPosition:(CGPointMake(_nouvPosX, _nouvPosY))];
                        
                    }
                }
            }
            
            if(recognizer.state == UIGestureRecognizerStateEnded)
            {   _centreRotation.x = 0;
                _centreRotation.y = 0;
                [_coordinatesBeforeRotation removeAllObjects]; }
        }else if([_selectedNodes count] == 1){
            if(![_selectedNode.name isEqualToString:@"table"]) {
                SKAction *rotation = [SKAction rotateByAngle:-recognizer.rotation duration:0];
                
                if([_selectedNodes[0] zRotation] >= 2 * M_PI) {
                    [_selectedNodes[0] setZRotation:fmod([_selectedNodes[0] zRotation],  (2 * M_PI))];
                }
                
                if([_selectedNodes[0] zRotation] <= -2 * M_PI) {
                    [_selectedNodes[0] setZRotation:fmod([_selectedNodes[0] zRotation],  (2 * M_PI))];
                }
                
                [_selectedNodes[0] runAction:rotation];
                recognizer.rotation = 0;
            }
        }
    }

}

/*!
 * @discussion Méthode qui est appelée lorsqu'on effectue un "appuie long".
 * @param recognizer le recognizer qui détecte le RotateGesture
 */
-(void)handleLongPress:(UILongPressGestureRecognizer *)gestureRecognizer
{
    if (gestureRecognizer.state != UIGestureRecognizerStateEnded) {
        return;
    }
    CGPoint touchLocation = [_touch locationInNode:self];
    SKNode *touchedNode = [self nodeAtPoint:touchLocation];
    
    NSLog(@"%@ has been touched. Triple tap.",touchedNode.name);
    NSString *actionSheetTitle = @"Opérations sur les noeuds";
    NSString *destructiveTitle = @"Supprimer";
    NSString *duplicateTitle = @"Duppliquer";
    NSString *rotateTitle = @"Mode Rotation";
    NSString *scaleTitle = @"Mode Mis à echelle";
    NSString *scaleRotateTitle = @"Mode Mis à echelle + Rotation";
    NSString *cancelTitle = @"Annuler";
    UIActionSheet *actionSheet = [[UIActionSheet alloc]
                                  initWithTitle:actionSheetTitle
                                  delegate:self
                                  cancelButtonTitle:cancelTitle
                                  destructiveButtonTitle:destructiveTitle
                                  otherButtonTitles:duplicateTitle,rotateTitle, scaleTitle, scaleRotateTitle, nil];
    
    
    [actionSheet setTag: 1];
    [actionSheet showInView:self.view];
}





#pragma mark -
#pragma mark Utility methods

/*!
 * @discussion Méthode qui applique un effet de selection lorsqu'un noeud est séléctionné
 * @param selectedNode le noeud sélectionné
 */
-(void) highlightNode:(AbstractNode*) selectedNode {
    SKColor *color = [SKColor colorWithRed:248/255.0 green:231/255.0 blue:28/255.0 alpha:0.5];
    SKAction *pulseColor = [SKAction sequence:@[[SKAction colorizeWithColor:color colorBlendFactor:1.0 duration:0.15],[SKAction waitForDuration:0.1]
                                                ]];
    [selectedNode runAction: pulseColor ];
    
}

/*!
 * @discussion Méthode qui applique un effet de déselection lorsqu'un noeud est déséléctionné
 * @param selectedNode le noeud sélectionné
 */
-(void) unHighlightNode:(AbstractNode*) selectedNode {
    if(![selectedNode.name isEqualToString:@"table"]) {
        [selectedNode runAction:[SKAction colorizeWithColor:[SKColor whiteColor] colorBlendFactor:1.0 duration:0]];
    }
}

/*!
 * @discussion Méthode qui permet d'effectuer le capture d'ecran d'une scene
 * @return La capture de l'écran.
 */
-(UIImage*) sceneCapture {
    UIGraphicsBeginImageContextWithOptions(self.view.bounds.size, NO, 1);
    [self.view drawViewHierarchyInRect:self.view.bounds afterScreenUpdates:YES];
    UIImage *viewImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return viewImage;
}


/*!
 * @discussion Méthode qui convertit un angle  degré -> redian.
 * @param degree l'angle en degré
 * @return l'angle en radian.
 */
float degToRad(float degree) {
    return degree / 180.0f * M_PI;
}



/*!
 * @discussion Méthode qui convertit un angle  degré -> redian.
 * @param degree l'angle en degré
 * @return l'angle en radian.
 */
float RadtoDeg(float rad) {
    return 180.0f * rad/M_PI;
}
/*!
 * @discussion Méthode qui s'assure que l'on reste dans les limites de l'arriére plan.
 (sources: http://www.raywenderlich.com/2343/cocos2d-tutorial-for-ios-how-to-drag-and-drop-sprites )
 * @param newPos La position actuelle du noeud.
 * @return La  nouvelle position lorsque le noeud allait déborder.
 */
- (CGPoint)boundLayerPos:(CGPoint)newPos {
    CGSize winSize = self.size;
    CGPoint retval = newPos;
    retval.x = MIN(retval.x, 0);
    retval.x = MAX(retval.x, -[_table size].width+ winSize.width);
    retval.y = [self position].y;
    return retval;
}


-(CGFloat)getMinX {
    CGFloat minx = 2000;
    for(AbstractNode* node in _selectedNodes) {
        if(node.position.x < minx)
            minx =node.position.x;
    }
    
    return minx;
}


-(CGFloat)getMaX {
    CGFloat max = -1;
    for(AbstractNode* node in _selectedNodes) {
        if(node.position.x > max)
            max =node.position.x;
    }
    return max;
}


-(CGFloat)getMinY {
    CGFloat miny = 2000;
    for(AbstractNode* node in _selectedNodes) {
        if(node.position.y < miny)
            miny =node.position.y;
    }
    
    return miny;
}


-(CGFloat)getMaY {
    CGFloat max = -1;
    for(AbstractNode* node in _selectedNodes) {
        if(node.position.y > max)
            max =node.position.y;
    }
    return max;
}


// Sources: PNPOLY - Point Inclusion in Polygon Test W. Randolph Franklin (WRF)
// How do I find if a point lies within a polygon?
int pnpoly (int nvert, float vertx[], float verty[], float testx, float testy)
{
    int i, j, c = 0;
    for (i = 0, j = nvert-1; i < nvert; j = i++) {
        if ( ((verty[i]>testy) != (verty[j]>testy)) &&
            (testx < (vertx[j]-vertx[i]) * (testy-verty[i]) / (verty[j]-verty[i]) + vertx[i]) )
            c = !c;
    }
    return c;
}


/*!
 * @discussion Méthode qui vérifie si un point est à l'interieur de la zone d'édition
 * @param p coordonées du point
 * @return BOOL.
 */
- (BOOL) containsPoint:(CGPoint)p {
    float vertx[4] = {30, self.size.width - 15, self.size.width-15, 30};
    float verty[4] = {self.size.height, self.size.height, 55, 55};
    return pnpoly (4, vertx, verty, p.x, p.y);
}


/*!
 * @discussion Méthode qui vérifie si tous les noeuds selectionnnées sont dansla zone d'édition
 * @param p coordonées du point
 * @return BOOL.
 */
- (BOOL) allInside {
    for (AbstractNode* node in _selectedNodes) {
        if (![self containsPoint:node.position]) {
            return false;
        }
    }
    return TRUE;
}

@end
