//
//  CardPropertyViewController.m
//  ClientLegerTab
//
//  Created by Mos on 26/11/2015.
//  Copyright (c) 2015 Mos. All rights reserved.
//

#import "CardPropertyViewController.h"
#import "MapSingleton.h"
#import "Utility.h"


@interface CardPropertyViewController ()

@end

@implementation CardPropertyViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"backgroundPinBallProp"]];
    self.cardTitle.text = [[MapSingleton sharedInstance] getCardTitle];
    self.cardUser.text = [[MapSingleton sharedInstance] getCardUser];;
    self.cardDifficulty.text = [Utility IntegerToString:[[MapSingleton sharedInstance] getCardDifficulty]];
    self.cardPBC.text = [Utility IntegerToString:[[MapSingleton sharedInstance] getCardpbcirculaire]];
    self.cardPBT.text = [Utility IntegerToString:[[MapSingleton sharedInstance] getCardpbtriangulaire]];
    self.cardPC.text = [Utility IntegerToString:[[MapSingleton sharedInstance] getCardpcible]];
    self.cardPBille.text = [Utility IntegerToString:[[MapSingleton sharedInstance] getCardpbille]];
    self.cardPPG.text = [Utility IntegerToString:[[MapSingleton sharedInstance] getCardpgagner]];
    
}


- (IBAction)didClickedEnregistrer:(id)sender {
    [[MapSingleton sharedInstance] setCardTitle:self.cardTitle.text];
    [[MapSingleton sharedInstance] setCardUser:self.cardUser.text];
    [[MapSingleton sharedInstance] setCardDifficulty:[self.cardDifficulty.text intValue]];
    [[MapSingleton sharedInstance] setCardpbcirculaire:[self.cardPBC.text intValue]];
    [[MapSingleton sharedInstance] setCardpbtriangulaire:[self.cardPBT.text intValue]];
    [[MapSingleton sharedInstance] setCardpcible:[self.cardPC.text intValue]];
    [[MapSingleton sharedInstance] setCardpbille:[self.cardPBille.text intValue]];
    [[MapSingleton sharedInstance] setCardpgagner:[self.cardPPG.text intValue]];
    
    [self dismissViewControllerAnimated:TRUE completion:nil];
}

@end
