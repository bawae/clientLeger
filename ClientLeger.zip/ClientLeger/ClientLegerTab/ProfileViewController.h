//
//  ProfileViewController.h
//  ClientLegerTab
//
//  Created by Mouhamadou Oumar Sall on 26/11/2015.
//  Copyright (c) 2015 Mos. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProfileViewController : UIViewController<UIImagePickerControllerDelegate, UIActionSheetDelegate>


@end

