//
//  ParserXML.h
//  ClientLegerTab
//
//  Classe qui se charge de lire une carte xml et peupler la scene
//
//  Created by Mos on 03/11/2015.
//  Copyright (c) 2015 Mos. All rights reserved.
//

#import "VisitorXML.h"
#import "EditorScene.h"
#import "ParserXML.h"
#import "NodeHeader.h"
#import "NodeHeader.h"
#import "MapSingleton.h"
#import "Utility.h"




@interface ParserXML ()
@end

@implementation ParserXML
- (instancetype) initWithDoc:(DDXMLDocument*)doc  {
    
    if (self = [super init]) {
        doc_ = doc;
        
    }
    return self;
}



/*!
 * @discussion Methode qui retourne le contenu de la scene apres avoir parsé une carte xml.
 *
 * @param doc le document xml
 * @return un noeud avec l'ensemble des elements de la scene.
 */
+ (AbstractNode*) getEditorScene:(DDXMLDocument*) doc {
    AbstractNode * table;
    //TODO: rechecker
    table = (AbstractNode*)[SKSpriteNode new];
    [table setName:@"table"];
    NSLog([doc XMLString]);
    NSError *error;
    NSArray *nodes =[doc nodesForXPath:@"///Type" error:&error];
    NSLog(@"getEditorScene");
    FactoryNode* factoryNode = [FactoryNode new];
    for (DDXMLElement* node in nodes) {
        NSString* idNode = [[node attributeForName:@"id"]stringValue];
        if([idNode isEqualToString:@"0"])
            continue;
        NSString* rotationNodeString = [[node attributeForName:@"Rotation"]stringValue];
        CGFloat rotationzNode = (CGFloat)[rotationNodeString floatValue];
        NSString* positionNodeString = [[node attributeForName:@"Position"]stringValue];
        NSArray* positionsNode = [positionNodeString componentsSeparatedByString: @" "];
        //Passer des coordonnées OpenGl aux coordonnées de SpriteKit
        //l'anchorPoint (0,0) aux coordonnées OpenGL du client Lourd (-xPlus, -yPlus)
        CGFloat xPositionNode = (CGFloat)[positionsNode[0] floatValue] + xPlus;
        CGFloat yPositionNode = (CGFloat)[positionsNode[1] floatValue] + yPlus;
        NSString* scaleNodeString = [[node attributeForName:@"Scale"]stringValue];
        NSArray* scalesNode = [scaleNodeString componentsSeparatedByString: @" "];
        CGFloat xScaleNode = (CGFloat)[scalesNode[0] floatValue];
        CGFloat yScaleNode = (CGFloat)[scalesNode[1] floatValue];
        // s'il s'agit d'un portail
        
        if ([idNode isEqualToString:TYPE_PORTAIL]) {
            NSString* portailId = [[node attributeForName:@"PortalLink"]stringValue];
            AbstractNode* aNode = [factoryNode createNode:idNode];
            aNode.name = [NSString stringWithFormat:@"NodePortail_%@", portailId];
            aNode.zRotation =rotationzNode;
            aNode.position = CGPointMake(xPositionNode, yPositionNode);
            aNode.zPosition = 0.00;
            aNode.xScale = xScaleNode;
            aNode.yScale = yScaleNode;
            [table addChild:aNode];
        }else{
            AbstractNode* aNode = [factoryNode createNode:idNode];
            aNode.zRotation =rotationzNode;
            aNode.position = CGPointMake(xPositionNode, yPositionNode);
            aNode.zPosition = 0.00;
            aNode.xScale = xScaleNode;
            aNode.yScale = yScaleNode;
            [table addChild:aNode];
        }
        
        NSLog(@"LOG: ParserXML, Found a %@ node in the document", idNode);
    }
    
    NSArray *points =[doc nodesForXPath:@"///Point" error:&error];
    for (DDXMLElement* point in points) {
        NSString* PtsBC = [[point attributeForName:@"PtsBC"]stringValue];
        [[MapSingleton sharedInstance] setCardpbcirculaire:[PtsBC intValue]];
        NSString* PtsBT = [[point attributeForName:@"PtsBT"]stringValue];
        [[MapSingleton sharedInstance] setCardpbtriangulaire:[PtsBT intValue]];
        NSString* PtsCible = [[point attributeForName:@"PtsCible"]stringValue];
        [[MapSingleton sharedInstance] setCardpcible:[PtsCible intValue]];
        NSString* PtsNewBall = [[point attributeForName:@"PtsNewBall"]stringValue];
        [[MapSingleton sharedInstance] setCardpbille:[PtsNewBall intValue]];
        NSString* PtsEndGame = [[point attributeForName:@"PtsEndGame"]stringValue];
        [[MapSingleton sharedInstance] setCardpgagner:[PtsEndGame intValue]];
        NSString* Difficulty = [[point attributeForName:@"Difficulty"]stringValue];
        [[MapSingleton sharedInstance] setCardpbtriangulaire:[Difficulty intValue]];
    }
    
    return table;
}


@end
