//
//  AbstractNode.m
//  
//
//  Created by Mos on 19/10/2015.
//
//
#import <Foundation/Foundation.h>
#import "AbstractNode.h"

@implementation AbstractNode  


- (instancetype) init {
    if (self = [super init]) {
    
    }
    return self;
}

@end