//
//  NodeButoirTriangulaireR.m
//
//
//  Created by Mos on 19/10/2015.
//
//

#import <Foundation/Foundation.h>
#import "NodeButoirTriangulaireR.h"


@implementation NodeButoirTriangulaireR

- (instancetype) init {
    // note that [super init] will call the SpaceshipNode's init method
    if (self = [super init]) {
        NSLog(@"A new NodeButoirTriangulaireL was just init'ed.");
        self = (NodeButoirTriangulaireR*) [[SKSpriteNode alloc]initWithImageNamed:@"NodeButoirTriangulaireR"];
        self.name =@"NodeButoirTriangulaireR";
    }
    return self;
}
@end
