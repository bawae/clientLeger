//
//  SettingViewController.m
//  ClientLegerTab
//
//  Created by Mouhamadou Oumar Sall on 26/11/2015.
//  Copyright (c) 2015 Mos. All rights reserved.
//
#import "SettingViewController.h"

@interface SettingViewController ()

@end

@implementation SettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
