//
//  ViewMenuController.m
//  Projet3_Chat
//
//  Created by Wael Bayoudh on 16-02-18.
//  Copyright © 2016 Wael Bayoudh. All rights reserved.
//

#import "ViewMenuController.h"

@interface ViewMenuController ()

@end

@implementation ViewMenuController
@synthesize inputStream;
@synthesize outputStream;
@synthesize isGuest;



- (void)viewDidLoad {
    [super viewDidLoad];
    if (isGuest==false) {
        // Do any additional setup after loading the view.
        [inputStream setDelegate:self];
        [outputStream setDelegate:self];
        //[self initNetworkCommunication];
        // Do any additional setup after loading the view, typically from a nib.
        countInt=0;
        timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(updateTimer) userInfo:nil repeats:YES];
    }
    

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void) updateTimer
{
    int taille = 4;
    int magicNumber = 0;
    NSData *dataMagicNumber = [NSData dataWithBytes: &magicNumber length:sizeof(magicNumber)];
    NSData *dataTaille = [NSData dataWithBytes: &taille length:sizeof(taille)];
    NSMutableData *data = [[NSMutableData alloc] initWithData:dataTaille];
    [data appendData:dataMagicNumber];
    [outputStream write:[data bytes] maxLength:[data length]];
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
