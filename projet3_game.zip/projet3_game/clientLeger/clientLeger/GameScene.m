//
//  GameScene.m
//  clientLeger
//  Inspiré de : http://www.raywenderlich.com/2343/cocos2d-tutorial-for-ios-how-to-drag-and-drop-sprites
//  Created by Wael Bayoudh on 16-03-05.
//  Copyright (c) 2016 Wael Bayoudh. All rights reserved.
//

#import "GameScene.h"

@interface GameScene ()

@property (nonatomic, strong) SKSpriteNode *table;
@property (nonatomic, strong) SKSpriteNode *selectedNode;
@property (nonatomic, strong) NSMutableArray *selectedNodes;

@end


@implementation GameScene

-(void)didMoveToView:(SKView *)view {
    _table=(SKSpriteNode*)[self childNodeWithName:@"table"];
    UIPanGestureRecognizer *gestureRecognizer = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePanFrom:)];
    [[self view] addGestureRecognizer:gestureRecognizer];
    
   }

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    /* Called when a touch begins */
    

        UITouch *touch = [touches anyObject];
        CGPoint positionInScene = [touch locationInNode:self];
        [self selectNodeForTouch:positionInScene];
}

-(void)update:(CFTimeInterval)currentTime {
    /* Called before each frame is rendered */
}

- (void)selectNodeForTouch:(CGPoint)touchLocation {
    //
    SKSpriteNode *touchedNode = (SKSpriteNode *)[self nodeAtPoint:touchLocation];
    
    //
    if ([touchedNode.name containsString:@"fix"]) {
        _selectedNode = touchedNode;
    }
    else if([touchedNode.name isEqualToString:@"table"]&& ![_selectedNode.name containsString:@"fix"]) {
        for (SKSpriteNode* nodeSelected in _selectedNodes) {
            [self unHighlightObject:nodeSelected];
        }
        [_selectedNodes removeAllObjects];
    }
    else if([touchedNode.name isEqualToString:@"table"]&& [_selectedNode.name containsString:@"fix"]) {
        NSArray *arrayName = [_selectedNode.name componentsSeparatedByString:@"_"];
        NSString* nodeName = arrayName[0];
        
        SKSpriteNode* node = [SKSpriteNode spriteNodeWithImageNamed:nodeName];
        node.position = touchLocation;
        node.name = nodeName;
        [self addChild:node];
        [_selectedNode setName: @""];
        //[self selectNodeForTouch:touchLocation];
    }
    else
    {
        if(![[touchedNode name] containsString:@"fix"]) {
            [_selectedNode setName: @""];
            if(![_selectedNodes containsObject:touchedNode]) {
                
                [_selectedNodes addObject:touchedNode ];
                [self highlightObject:touchedNode];
                
            }
            else if([_selectedNodes containsObject:touchedNode]) {
                
                [_selectedNodes removeObject:touchedNode];
                [self unHighlightObject:touchedNode];
                
            }
        }
    }
    
    
    
            
    if([[touchedNode name] isEqualToString:@"duplicate_tool"]) {
        for (SKSpriteNode* nodeSelected in _selectedNodes) {
            SKSpriteNode *newNode = [SKSpriteNode spriteNodeWithImageNamed:nodeSelected.name];
            
            newNode.position = CGPointMake(nodeSelected.position.x + 10, nodeSelected.position.y);
            [self addChild:newNode];
        }
    }
    else if([[touchedNode name] isEqualToString:@"delete_tool"]) {
        for (SKSpriteNode* nodeSelected in _selectedNodes) {
            [nodeSelected removeFromParent];
        }
    }
    
}
- (void)panForTranslation:(CGPoint)translation {
    for (SKSpriteNode* nodeSelected in _selectedNodes) {
        CGPoint position = [nodeSelected position];
        //if(![_selectedNode.name containsString:@"fix"] && ![_selectedNode.name containsString:@"table"]) {
        [nodeSelected setPosition:CGPointMake(position.x + translation.x, position.y + translation.y)];
    }
}


- (void)handlePanFrom:(UIPanGestureRecognizer *)recognizer {
    if (recognizer.state == UIGestureRecognizerStateBegan) {
        
        CGPoint touchLocation = [recognizer locationInView:recognizer.view];
        
        touchLocation = [self convertPointFromView:touchLocation];
        [self selectNodeForTouch:touchLocation];
        
    } else if (recognizer.state == UIGestureRecognizerStateChanged) {
        
        CGPoint translation = [recognizer translationInView:recognizer.view];
        translation = CGPointMake(translation.x, -translation.y);
        [self panForTranslation:translation];
        [recognizer setTranslation:CGPointZero inView:recognizer.view];
        
    } else if (recognizer.state == UIGestureRecognizerStateEnded) {
        
    }
}
-(void) highlightObject:(SKSpriteNode*) selectedNode {
    SKColor *color = [SKColor colorWithRed:248/255.0 green:231/255.0 blue:28/255.0 alpha:0.5];
    SKAction *pulseColor = [SKAction sequence:@[[SKAction colorizeWithColor:color colorBlendFactor:1.0 duration:0.15],[SKAction waitForDuration:0.1]
                                                ]];
    [selectedNode runAction: pulseColor ];
    
}

-(void) unHighlightObject:(SKSpriteNode*) selectedNode {
   
        [selectedNode runAction:[SKAction colorizeWithColor:[SKColor whiteColor] colorBlendFactor:1.0 duration:0]];

}
/*!
 * @discussion Méthode qui convertit un angle  degré -> redian.
 * @param degree l'angle en degré
 * @return l'angle en radian.
 */
float RadiontoDegree(float radion) {
    return 180.0f * radion/M_PI;
}

@end
