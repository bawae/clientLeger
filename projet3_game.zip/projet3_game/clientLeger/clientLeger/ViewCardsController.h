//
//  ViewCardsController.h
//  Projet3_Chat
//
//  Created by Wael Bayoudh on 16-02-18.
//  Copyright © 2016 Wael Bayoudh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewCardsController : UIViewController
- (IBAction)menuDisplayAction:(id)sender;
@property (weak, nonatomic) IBOutlet UIView *slideMenu;

@end
