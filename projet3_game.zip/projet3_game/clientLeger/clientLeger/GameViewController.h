//
//  GameViewController.h
//  clientLeger
//

//  Copyright (c) 2016 Wael Bayoudh. All rights reserved.
//

#import <UIKit/UIKit.h>/Users/Wael/Desktop/log3900-03/Projet3_Chat/Projet3_Chat/Projet3_ChatImages
#import <SpriteKit/SpriteKit.h>

@interface GameViewController : UIViewController
- (IBAction)menuDisplayAction:(id)sender;
@property (weak, nonatomic) IBOutlet UIView *slideMenu;

@end
