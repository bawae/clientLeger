//
//  ViewEditorController.m
//  Projet3_Chat
//
//  Created by Wael Bayoudh on 16-02-18.
//  Copyright © 2016 Wael Bayoudh. All rights reserved.
//

#import "GameScene.h"
#import "ViewEditorController.h"

@interface ViewEditorController ()

@end

@implementation ViewEditorController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.slideMenu.hidden= YES;
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)menuDisplayAction:(id)sender {
    if (self.slideMenu.isHidden)
    {
        self.slideMenu.hidden= NO;
    }
    else
    {
        self.slideMenu.hidden= YES;
    }
}

/*- (IBAction)minusScale:(id)sender {
    self.image.frame= CGRectMake(291,135,self.image.frame.size.width-10,self.image.frame.size.height-10);
}

- (IBAction)plusScale:(id)sender {
    self.image.frame= CGRectMake(291,135,self.image.frame.size.width+10,self.image.frame.size.height+10);
}*/
- (void)viewWillLayoutSubviews
{
    [super viewWillLayoutSubviews];
    
    // Configure the view.
    SKView * skView = (SKView *)self.view;
    if (!skView.scene) {
        skView.showsFPS = YES;
        skView.showsNodeCount = YES;
        
        // Create and configure the scene.
        SKScene * scene = [GameScene sceneWithSize:skView.bounds.size];
        scene.scaleMode = SKSceneScaleModeAspectFill;
        
        // Present the scene.
       [skView presentScene:scene];
    }
}

/*- (BOOL)shouldAutorotate
{
    return YES;
}*/

- (NSUInteger)supportedInterfaceOrientations
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return UIInterfaceOrientationMaskAllButUpsideDown;
    } else {
        return UIInterfaceOrientationMaskAll;
    }
}


@end
