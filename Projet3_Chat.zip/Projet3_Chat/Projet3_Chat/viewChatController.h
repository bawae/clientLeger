//
//  ViewController.h
//  Projet3_Chat
//
//  Created by Wael Bayoudh on 16-02-04.
//  Copyright © 2016 Wael Bayoudh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface viewChatController : UIViewController
{
    
    int countInt;
    NSTimer *timer;

}
@property (strong, nonatomic) NSMutableArray *friends; //Trying to pass data here
@property (weak, nonatomic) IBOutlet UIScrollView *scrollViewOutlet;
@property (weak, nonatomic) IBOutlet UITextField *messageOutlet;

@property (nonatomic, retain) NSMutableArray *messages;

@property (nonatomic, retain) NSInputStream *inputStream;
@property (nonatomic, retain) NSOutputStream *outputStream;

- (IBAction)sendMessageAction:(id)sender;
@property (weak, nonatomic) IBOutlet UITextView *textView;

@end

