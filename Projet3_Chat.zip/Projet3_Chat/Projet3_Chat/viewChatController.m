//
//  ViewController.m
//  Projet3_Chat
//
//  Created by Wael Bayoudh on 16-02-04.
//  Copyright © 2016 Wael Bayoudh. All rights reserved.
//  Inspired by: http://www.raywenderlich.com/3932/networking-tutorial-for-ios-how-to-create-a-socket-based-iphone-app-and-server
//

#import "viewChatController.h"

@interface viewChatController ()
//@property (strong, nonatomic) NSMutableArray *friends; //Trying to pass data here
@end

@implementation viewChatController
@synthesize messages;
@synthesize inputStream;
@synthesize outputStream;

- (void)viewDidLoad {
    [super viewDidLoad];
    //[self initNetworkCommunication];
    // Do any additional setup after loading the view, typically from a nib.
    countInt=0;
    
    timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(updateTimer) userInfo:nil repeats:YES];
   /* self.outputStream = [self.friends objectAtIndex:0];
    self.inputStream = [self.friends objectAtIndex:1];
    NSLog(@"output %@", self.friends.firstObject);*/
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void) updateTimer
{
    int taille = 4;
    int magicNumber = 0;
    NSData *dataMagicNumber = [NSData dataWithBytes: &magicNumber length:sizeof(magicNumber)];
    NSData *dataTaille = [NSData dataWithBytes: &taille length:sizeof(taille)];
    NSMutableData *data = [[NSMutableData alloc] initWithData:dataTaille];
    [data appendData:dataMagicNumber];
    [outputStream write:[data bytes] maxLength:[data length]];
    
}
/*- (void) initNetworkCommunication {
    
    CFReadStreamRef readStream;
    CFWriteStreamRef writeStream;
    CFStreamCreatePairWithSocketToHost(NULL, (CFStringRef)@"132.207.156.237", 5002, &readStream, &writeStream);
    //CFStreamCreatePairWithSocketToHost(NULL,(CFStringRef) self.ipAdress.text, 5002, &readStream, &writeStream);
    
    
    //inputStream = (__bridge NSInputStream *)readStream;
    //outputStream = (__bridge NSOutputStream *)writeStream;
    inputStream=[self.friends objectAtIndex:1];
    outputStream=[self.friends objectAtIndex:0];
    [inputStream setDelegate:self];
    [outputStream setDelegate:self];
    [inputStream scheduleInRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
    [outputStream scheduleInRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
    [inputStream open];
    [outputStream open];
    
}*/


- (void)stream:(NSStream *)theStream handleEvent:(NSStreamEvent)streamEvent {
    
    NSLog(@"stream event %lu", (unsigned long)streamEvent);
    
    switch (streamEvent) {
            
        case NSStreamEventOpenCompleted:
            NSLog(@"Stream opened");
            break;
        case NSStreamEventHasBytesAvailable:
            
            if (theStream == inputStream) {
                
                uint8_t buffer[1024];
                int len;
                
                while ([inputStream hasBytesAvailable]) {
                    len = [inputStream read:buffer maxLength:sizeof(buffer)];
                    if (len > 0) {
                        
                        NSMutableData *output = [[NSMutableData alloc] initWithBytes:buffer length:len];
                        
                        if (nil != output) {
                            
                            //NSLog(@"server said: %@", output);
                            [self messageReceived:output];
                            
                        }
                    }
                }
            }
            break;
            
            
        case NSStreamEventErrorOccurred:
            
            NSLog(@"Can not connect to the host!");
            break;
            
        case NSStreamEventEndEncountered:
            
            [theStream close];
            [theStream removeFromRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
            theStream = nil;
            
            break;
        default:
            NSLog(@"Unknown event");
    }
    
}

- (void) messageReceived:(NSMutableData *)message {
    
    NSData *subarraySize = [message subdataWithRange:NSMakeRange(0, 4)];
    NSData *subarrayMagicNumber = [message subdataWithRange:NSMakeRange(4, 4)];
    int taille = CFSwapInt32LittleToHost(*(int*)([subarraySize bytes]));
    NSData *subarrayData = [message subdataWithRange:NSMakeRange(8, taille-4) ];
    int magicNumber = CFSwapInt32LittleToHost(*(int*) ([subarrayMagicNumber bytes]));
    NSString *text = [[NSString alloc] initWithData:subarrayData encoding:NSUTF8StringEncoding];
    //text = [text stringByReplacingOccurrencesOfString:(@"\n") withString:(@" ")];
    [self.messages addObject:text];
    
    UILabel *label =  [[UILabel alloc] initWithFrame: CGRectMake(8,8+countInt*60,554,60)];
    label.lineBreakMode = NSLineBreakByWordWrapping;
    label.numberOfLines = 0;
    label.adjustsFontSizeToFitWidth = YES;
    self.scrollViewOutlet.autoresizesSubviews = YES;
    self.scrollViewOutlet.contentMode = UIViewContentModeScaleToFill;
    
    
    [label setTextAlignment:NSTextAlignmentLeft];
    label.layer.borderColor = [UIColor blueColor].CGColor;
    label.text= [NSString stringWithFormat:@"%@",text];
    [self.scrollViewOutlet addSubview:label];
    
    //self.scrollViewOutlet.contentSize= CGSizeMake(554,countInt*70);
    countInt ++;
    
    //[self.tView reloadData];
    /*NSIndexPath *topIndexPath = [NSIndexPath indexPathForRow:messages.count-1
                                                   inSection:0];
    [self.tView scrollToRowAtIndexPath:topIndexPath
                      atScrollPosition:UITableViewScrollPositionMiddle
                              animated:YES];*/
    
    NSLog(@"U just received %@",text);
    
}
- (IBAction)sendMessageAction:(id)sender {
    if(self.messageOutlet.text.length==0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Message vide"
                                                        message:@"Vous ne pouvez pas envoyer un message vide"
                                                       delegate:self
                                              cancelButtonTitle:@"Annuler"
                                              otherButtonTitles:nil, nil];
        [alert show];
    }
    else{
            //text = [text stringByReplacingOccurrencesOfString:(@"\n") withString:(@" ")];
            [self.messages addObject:self.messageOutlet.text];
            // [self.tView reloadData];
            NSIndexPath *topIndexPath = [NSIndexPath indexPathForRow:messages.count-1
                                                   inSection:0];
            //[self.tView scrollToRowAtIndexPath:topIndexPath
            //                  atScrollPosition:UITableViewScrollPositionMiddle
            //                           animated:YES];
    
        NSLog(@"U just sent %@",self.messageOutlet.text);
    
        NSDate *myDate = [[NSDate alloc] init];
        NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
        [dateFormat setDateFormat:@" yyyy-MM-dd HH:mm:ss "];
        NSString *timestamp = [dateFormat stringFromDate:myDate];
            
        NSString *response  = [NSString stringWithFormat:@"%@ %@:\n%@",timestamp, @"ADNANE",self.messageOutlet.text];
        int taille = 0;
        int magicNumber = 1;
        NSData *dataMagicNumber = [NSData dataWithBytes: &magicNumber length:sizeof(magicNumber)];
        NSData *data = [[NSData alloc] initWithData:[response dataUsingEncoding:NSUTF8StringEncoding]];
        taille = 4 + data.length;
        NSData *dataTaille = [NSData dataWithBytes: &taille length:sizeof(taille)];
        NSMutableData *totalData = [[NSMutableData alloc] initWithData:dataTaille];
        [totalData appendData:dataMagicNumber];
        [totalData appendData:data];
        [outputStream write:[totalData bytes] maxLength:[totalData length]];
            
        UILabel *label =  [[UILabel alloc] initWithFrame: CGRectMake(8,8+countInt*60,554,60)];
        label.lineBreakMode = NSLineBreakByWordWrapping;
        label.numberOfLines = 0;
        label.adjustsFontSizeToFitWidth = YES;
        self.scrollViewOutlet.autoresizesSubviews = YES;
        self.scrollViewOutlet.contentMode = UIViewContentModeScaleToFill;
            
            
        [label setTextAlignment:NSTextAlignmentRight];
        label.layer.borderColor = [UIColor blackColor].CGColor;
        label.text= [NSString stringWithFormat:@"%@ %@: %@",timestamp,@"adnane",self.messageOutlet.text];
        [self.scrollViewOutlet addSubview:label];
        self.messageOutlet.text = @"";
        countInt++;
    }
}
@end
