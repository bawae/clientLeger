//
//  viewLoginController.h
//  Projet3_Chat
//
//  Created by Wael Bayoudh on 16-02-04.
//  Copyright © 2016 Wael Bayoudh. All rights reserved.
//

#ifndef viewLoginController_h
#define viewLoginController_h
#import <UIKit/UIKit.h>

@interface viewLoginController : UIViewController
@property (strong, nonatomic) NSMutableArray *friends; //Trying to pass data here
@property (weak, nonatomic) IBOutlet UITextField *usernameOutlet;
@property (weak, nonatomic) IBOutlet UITextField *ipAddressOutlet;
@property (weak, nonatomic) IBOutlet UITextField *portOutlet;

@property (nonatomic, retain) NSInputStream *inputStream;
@property (nonatomic, retain) NSOutputStream *outputStream;

- (IBAction)loginAction:(id)sender;
@end

#endif /* viewLoginController_h */
