//
//  main.m
//  Projet3_Chat
//
//  Created by Wael Bayoudh on 16-02-04.
//  Copyright © 2016 Wael Bayoudh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
