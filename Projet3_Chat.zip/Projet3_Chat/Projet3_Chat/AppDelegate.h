//
//  AppDelegate.h
//  Projet3_Chat
//
//  Created by Wael Bayoudh on 16-02-04.
//  Copyright © 2016 Wael Bayoudh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

