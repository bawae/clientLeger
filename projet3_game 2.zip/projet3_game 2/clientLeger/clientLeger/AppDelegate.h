//
//  AppDelegate.h
//  clientLeger
//
//  Created by Wael Bayoudh on 16-03-05.
//  Copyright © 2016 Wael Bayoudh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

