//
//  GameScene.h
//  clientLeger
//

//  Copyright (c) 2016 Wael Bayoudh. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface GameScene : SKScene

@end
