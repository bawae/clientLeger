//
//  viewLoginController.m
//  Projet3_Chat
//
//  Created by Wael Bayoudh on 16-02-04.
//  Copyright © 2016 Wael Bayoudh. All rights reserved.
//  Inspired by: http://www.raywenderlich.com/3932/networking-tutorial-for-ios-how-to-create-a-socket-based-iphone-app-and-server
//

#import "viewLoginController.h"
#import "viewChatController.h"
#import "ViewMenuController.h"


@interface viewLoginController ()
//@property (strong, nonatomic) NSMutableArray *friends; //Trying to pass data here
@end

@implementation viewLoginController
bool isAvailable = false;
bool isGuest = false;
@synthesize inputStream,outputStream;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)loginAction:(id)sender
{
    NSLog(@"Login Action");

    
    /*UINavigationController *navigationController;
    viewChatController *chatView = [[viewChatController alloc] initWithNibName: @"goToChatScreen" bundle: nil] ;
    navigationController = [[UINavigationController alloc] initWithRootViewController:chatView];*/
    
    //viewChatController *secondView = [self.storyboard instantiateViewControllerWithIdentifier:@"menuView"];
    
    
    [self initNetworkCommunication];
    int taille = 0;
    int taillePseudo = 0;
    int taillePassword = 0;
    int magicNumber = 2;
    
    NSData *dataMagicNumber = [NSData dataWithBytes: &magicNumber length:sizeof(magicNumber)];
    NSData *dataPseudo = [[NSData alloc] initWithData:[self.usernameOutlet.text dataUsingEncoding:NSUTF8StringEncoding]];
    taillePseudo = (int) dataPseudo.length;
    NSData *dataPassword = [[NSData alloc] initWithData:[self.passwordOutlet.text dataUsingEncoding:NSUTF8StringEncoding]];
    taillePassword = (int)dataPassword.length;
    NSData *dataSizePseudo = [NSData dataWithBytes: &taillePseudo length:sizeof(taillePseudo)];
    NSData *dataSizePassword = [NSData dataWithBytes: &taillePassword length:sizeof(taillePassword)];
    taille = 12 + (int)dataPassword.length + (int)dataPseudo.length;
    NSData *dataTaille = [NSData dataWithBytes: &taille length:sizeof(taille)];
    NSMutableData *totalData = [[NSMutableData alloc] initWithData:dataTaille];
    
    [totalData appendData:dataMagicNumber];
    [totalData appendData:dataSizePseudo];
    [totalData appendData:dataPseudo];
    [totalData appendData:dataSizePassword];
    [totalData appendData:dataPassword];
    [outputStream write:[totalData bytes] maxLength:[totalData length]];
    
    uint8_t buffer[9];
    [inputStream read:buffer maxLength:sizeof(buffer)];
    
    if(buffer[8] == 0)
    {
        isAvailable = true;
        NSLog(@"Pseudo disponible");
    }
    
    else
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Ce pseudonyme est déjà pris!! "
                                                        message:@"Veuillez choisir un autre pseudonyme!!"
                                                       delegate:self
                                              cancelButtonTitle:@"Annuler"
                                              otherButtonTitles:nil, nil];
        self.usernameOutlet.text=nil;
        [alert show];
        
        isAvailable = false;
    }
    
}


- (IBAction)guestAction:(id)sender {
    isGuest=TRUE;
    isAvailable = true;
}




- (void) initNetworkCommunication {
    NSLog(@"Init Network Communication");
    
    CFReadStreamRef readStream;
    CFWriteStreamRef writeStream;
    CFStreamCreatePairWithSocketToHost(NULL, (CFStringRef)@"132.207.156.244", 5002, &readStream, &writeStream);
    //CFStreamCreatePairWithSocketToHost(NULL,(__bridge CFStringRef) self.ipAddressOutlet, 5002, &readStream, &writeStream);
    //CFStreamCreatePairWithSocketToHost(NULL, (__bridge CFStringRef)[[self ipAddressOutlet]text], [[[self portOutlet]text]integerValue], &readStream, &writeStream);
    
    
    inputStream = (__bridge NSInputStream *)readStream;
    outputStream = (__bridge NSOutputStream *)writeStream;
    [inputStream setDelegate:self];
    [outputStream setDelegate:self];
    [inputStream scheduleInRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
    [outputStream scheduleInRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
    [inputStream open];
    [outputStream open];
    
}

- (BOOL)shouldPerformSegueWithIdentifier:(NSString *)identifier sender:(id)sender
{
    if(isAvailable)
        return TRUE;
    else
        return FALSE;
}


- (void)prepareForSegue:(UIStoryboardSegue *)segue
                 sender:(id)sender
{
    if([segue.identifier isEqualToString:@"goToMenuScreen"] )
    {
        NSLog(@"Go to menu screen");
        ViewMenuController *detailView=[segue destinationViewController];
        detailView.outputStream = self.outputStream;
        detailView.inputStream = self.inputStream;
        detailView.usernameDisplayLabel= self.usernameOutlet.text;
        detailView.isGuest=false;

    }
    if([segue.identifier isEqualToString:@"guestAccess"])
    {
        NSLog(@"Guest Access");
        ViewMenuController *detailView=[segue destinationViewController];
        detailView.usernameDisplayLabel= @"Invité";
        detailView.isGuest=true;
    }
    
}





@end
