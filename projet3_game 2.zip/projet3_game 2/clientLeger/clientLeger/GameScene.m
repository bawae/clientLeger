//
//  GameScene.m
//  clientLeger
//  Inspiré de : http://www.raywenderlich.com/2343/cocos2d-tutorial-for-ios-how-to-drag-and-drop-sprites
//  Created by Wael Bayoudh on 16-03-05.
//  Copyright (c) 2016 Wael Bayoudh. All rights reserved.
//

#import "GameScene.h"

@interface GameScene ()

@property (nonatomic, strong) SKSpriteNode *table;
@property (nonatomic, strong) NSString *selectedNode;
@property (nonatomic, strong) NSMutableArray *selectedNodes;
@property (nonatomic, strong) NSMutableArray *duplicatedNodes;
@property (nonatomic, strong) NSMutableArray *rotatedNodes;
@property (nonatomic) CGPoint rotationCenter;
@property (nonatomic, strong) NSMutableArray* positionBeforeRotation;
@property (nonatomic) CGFloat newX;
@property (nonatomic) CGFloat newY;
@property (nonatomic) UITouch *touch;

@end

static BOOL NodeIsRotated       = FALSE;
static BOOL NodeIsTranslated    = TRUE;
static BOOL NodeIsPinched       = TRUE;
static BOOL NodeIsDuplicated    = FALSE;



@implementation GameScene

-(void)didMoveToView:(SKView *)view {
    _table=(SKSpriteNode*)[self childNodeWithName:@"table"];
    UIPanGestureRecognizer *gestureRecognizer = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePanFrom:)];
    [[self view] addGestureRecognizer:gestureRecognizer];
    _selectedNodes = [[NSMutableArray alloc] init];
    _duplicatedNodes = [[NSMutableArray alloc] init];

    _positionBeforeRotation = [[NSMutableArray alloc] init];
    
    UIPinchGestureRecognizer *pinch = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(handlePinch:)];
    [self.scene.view addGestureRecognizer:pinch];
    pinch.delegate = self;
    
    UIRotationGestureRecognizer *rot= [[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(handleRotate:)];
    [self.scene.view addGestureRecognizer:rot];
    rot.delegate = self;
    
    
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    /* Called when a touch begins */
    
    
    UITouch *touch = [touches anyObject];
    CGPoint positionInScene = [touch locationInNode:self];
    if ([touch tapCount] ==2)
    {
        for (SKSpriteNode* nodeSelected in _selectedNodes)
        {
            [self unHighlightObject:nodeSelected];
        }
        [_selectedNodes removeAllObjects];
    }
    
    
    [self selectNodeForTouch:positionInScene];
}

-(void)update:(CFTimeInterval)currentTime {
    /* Called before each frame is rendered */
}

- (void)selectNodeForTouch:(CGPoint)touchLocation
{
    SKSpriteNode *touchedNode = (SKSpriteNode *)[self nodeAtPoint:touchLocation];
    
    //
    if ([touchedNode.name containsString:@"fix"])
    {
        NSLog(@"Tool: %@ ",touchedNode.name);
        _selectedNode = touchedNode.name;
    }
    else if([touchedNode.name isEqualToString:@"table"]&& ![_selectedNode containsString:@"fix"])
    {
        NSLog(@"Touche sur table");
        /*for (SKSpriteNode* nodeSelected in _selectedNodes)
        {
            [self unHighlightObject:nodeSelected];
        }
        [_selectedNodes removeAllObjects];*/
        
        if(NodeIsDuplicated)
        {
            CGFloat x = 0;
            CGFloat y = 0;
            CGFloat distance = 0;
            CGFloat distance_2 = 0;
            CGFloat angle = 0;
            
            
            NSLog(@"Node Duplicated are put on table");
            
            for(int i = 0; i < [_selectedNodes count]; i++)
            {

                x = x + [[_selectedNodes objectAtIndex:i] position].x;
                y = y + [[_selectedNodes objectAtIndex:i] position].y;
            }
            _rotationCenter = CGPointMake(x/[_selectedNodes count], y/[_selectedNodes count]);
            
            
            
            for (SKSpriteNode* nodeDuplicated in _selectedNodes)
            {
                distance=sqrt( pow((nodeDuplicated.position.x -_rotationCenter.x),2)+pow((nodeDuplicated.position.y -_rotationCenter.y),2));
                distance_2=sqrt( pow((nodeDuplicated.position.x -_rotationCenter.x),2));
                
                //angle = -(acos(distance_2/distance) * 180 / M_PI);
                NSLog(@"%@  angle : %f",nodeDuplicated.name, angle);
                SKSpriteNode* newNode = [SKSpriteNode spriteNodeWithImageNamed:nodeDuplicated.name];
                
                [newNode setPosition:CGPointMake(
                                                 touchLocation.x+nodeDuplicated.position.x-_rotationCenter.x,
                                                 touchLocation.y+nodeDuplicated.position.y-_rotationCenter.y)];
                newNode.name = nodeDuplicated.name;

                [self addChild:newNode];
            }
            NodeIsDuplicated=false;
        }
    }
    else if([touchedNode.name isEqualToString:@"table"]&& [_selectedNode containsString:@"fix"])
    {
        
        NSArray *arrayName = [_selectedNode componentsSeparatedByString:@"_"];
        NSString* nodeName = arrayName[0];
        
        NSLog(@"On met %@ sur la table",nodeName);

        
        SKSpriteNode* node = [SKSpriteNode spriteNodeWithImageNamed:nodeName];
        node.position = touchLocation;
        node.name = nodeName;
        [self addChild:node];
        _selectedNode = @"";

    }
    else if(![touchedNode.name containsString:@"tool"])
    {
        NSLog(@"On Selectionne %@",touchedNode.name);
        if(![[touchedNode name] containsString:@"fix"])
        {
            if(![_selectedNodes containsObject:touchedNode])
            {
                NSLog(@"On le selectionne");
                [_selectedNodes addObject:touchedNode ];
                [self highlightObject:touchedNode];
                
            }
            else if([_selectedNodes containsObject:touchedNode]) {
                NSLog(@"On le deselectionne");
                [_selectedNodes removeObject:touchedNode];
                [self unHighlightObject:touchedNode];
                
            }
        }
    }
    else if([touchedNode.name containsString:@"tool"])
    {
        if([[touchedNode name] isEqualToString:@"duplicate_tool"])
        {
           // NodeIsRotated=false;
            //NodeIsTranslated=false;
            for (SKSpriteNode* nodeSelected in _selectedNodes)
            {
                SKSpriteNode *newNode = [SKSpriteNode spriteNodeWithImageNamed:nodeSelected.name];
                
                [_duplicatedNodes addObject:newNode];
                NodeIsDuplicated=TRUE;
                //newNode.position = CGPointMake(nodeSelected.position.x + 10, nodeSelected.position.y);
                //[self addChild:newNode];
            }
        }
        else if([[touchedNode name] isEqualToString:@"delete_tool"])
        {
            NodeIsRotated=false;
            
            for (SKSpriteNode* nodeSelected in _selectedNodes)
            {
                [nodeSelected removeFromParent];
            }
        }
        else if([[touchedNode name] isEqualToString:@"rotate_tool"])
        {
            NodeIsRotated=true;
            NodeIsTranslated=false;
            NodeIsPinched=false;
            NSLog(@"NodeIsRotated");
            
        }
    }
    
}
- (void)panForTranslation:(CGPoint)translation {
    
    if(NodeIsTranslated)
    {
        for (SKSpriteNode* nodeSelected in _selectedNodes)
        {
            NSLog(@"On bouge %@",nodeSelected.name);
            CGPoint position = [nodeSelected position];
            //if(![_selectedNode.name containsString:@"fix"] && ![_selectedNode.name containsString:@"table"]) {
            [nodeSelected setPosition:CGPointMake(position.x + translation.x, position.y + translation.y)];
        }
    }
}


- (void)handlePanFrom:(UIPanGestureRecognizer *)recognizer
{
    if (recognizer.state == UIGestureRecognizerStateBegan) {
        
        CGPoint touchLocation = [recognizer locationInView:recognizer.view];
        
        touchLocation = [self convertPointFromView:touchLocation];
        [self selectNodeForTouch:touchLocation];
        
    } else if (recognizer.state == UIGestureRecognizerStateChanged) {
        
        CGPoint translation = [recognizer translationInView:recognizer.view];
        translation = CGPointMake(translation.x, -translation.y);
        [self panForTranslation:translation];
        [recognizer setTranslation:CGPointZero inView:recognizer.view];
        
    } else if (recognizer.state == UIGestureRecognizerStateEnded) {
        
    }
}
-(void) highlightObject:(SKSpriteNode*) selectedNode {
    SKColor *color = [SKColor colorWithRed:248/255.0 green:231/255.0 blue:28/255.0 alpha:0.5];
    SKAction *pulseColor = [SKAction sequence:@[[SKAction colorizeWithColor:color colorBlendFactor:1.0 duration:0.15],[SKAction waitForDuration:0.1]
                                                ]];
    [selectedNode runAction: pulseColor ];
    
}

-(void) unHighlightObject:(SKSpriteNode*) selectedNode {
    
    [selectedNode runAction:[SKAction colorizeWithColor:[SKColor whiteColor] colorBlendFactor:1.0 duration:0]];
    
}
/*!
 * @discussion Méthode qui convertit un angle  degré -> redian.
 * @param degree l'angle en degré
 * @return l'angle en radian.
 */
float RadiontoDegree(float radion) {
    return 180.0f * radion/M_PI;
}


- (void)handleRotate:(UIRotationGestureRecognizer *)recognizer
{
    //if(NodeIsRotated)
    //{NSLog(@"handleRotate");
    // Rotation de plusieurs noeuds
    if([_selectedNodes count] > 1) {
        CGFloat x = 0;
        CGFloat y = 0;
        if(recognizer.state == UIGestureRecognizerStateBegan)
        { 
            for(int i = 0; i < [_selectedNodes count]; i++)
            {
                x = x + [[_selectedNodes objectAtIndex:i] position].x;
                y = y + [[_selectedNodes objectAtIndex:i] position].y;
            }
            _rotationCenter = CGPointMake(x/[_selectedNodes count], y/[_selectedNodes count]);
            
            for(int i = 0; i < [_selectedNodes count]; i++)
            {
                CGPoint pt = CGPointMake([[_selectedNodes objectAtIndex:i] position].x, [[_selectedNodes objectAtIndex:i] position].y);
                
                [_positionBeforeRotation addObject:[NSValue valueWithCGPoint:pt]];
            }}
        if(recognizer.state == UIGestureRecognizerStateChanged)
        {
            double angle = 0;
            CGPoint firstTouch =[recognizer locationOfTouch:0 inView:self.view];
            if(recognizer.numberOfTouches == 2){
                CGPoint secondTouch =[recognizer locationOfTouch:1 inView:self.view];
                angle = -(atan2(secondTouch.y - firstTouch.y, secondTouch.x - firstTouch.x) * 180 / M_PI);
            }
            
            //if ([self allInside]) {
                for(int i = 0; i < [_selectedNodes count]; i++)
                {
                    CGPoint initialPoint = [[_positionBeforeRotation objectAtIndex:i] CGPointValue];
                    _newX = cos(degreeToRadion(angle))*(initialPoint.x - _rotationCenter.x) - sin(degreeToRadion(angle))*(initialPoint.y - _rotationCenter.y) + _rotationCenter.x;
                    _newY = sin(degreeToRadion(angle))*(initialPoint.x - _rotationCenter.x) + cos(degreeToRadion(angle))*(initialPoint.y - _rotationCenter.y) + _rotationCenter.y;
                    
                    //CGPoint tempPosition = CGPointMake(_nouvPosX, _nouvPosY);
                    // if([self containsPoint:tempPosition])
                    [[_selectedNodes objectAtIndex:i] setPosition:(CGPointMake(_newX, _newY))];
                    
                }
            //}
        }
        
        if(recognizer.state == UIGestureRecognizerStateEnded)
        {   _rotationCenter.x = 0;
            _rotationCenter.y = 0;
            [_positionBeforeRotation removeAllObjects]; }
    }else if([_selectedNodes count] == 1){
        if(![_selectedNode isEqualToString:@"table"]) {
            SKAction *rotation = [SKAction rotateByAngle:-recognizer.rotation duration:0];
            
            if([_selectedNodes[0] zRotation] >= 2 * M_PI) {
                [_selectedNodes[0] setZRotation:fmod([_selectedNodes[0] zRotation],  (2 * M_PI))];
            }
            
            if([_selectedNodes[0] zRotation] <= -2 * M_PI) {
                [_selectedNodes[0] setZRotation:fmod([_selectedNodes[0] zRotation],  (2 * M_PI))];
            }
            
            [_selectedNodes[0] runAction:rotation];
            recognizer.rotation = 0;
        }
    }
   // }
    
}

- (void)handlePinch:(UIPinchGestureRecognizer *)recognizer
{
    SKAction *scale = [SKAction scaleBy:recognizer.scale duration:0];
    SKAction *scaleHeight = [SKAction scaleXBy:recognizer.scale y:1 duration:0];
    for(SKSpriteNode* node in _selectedNodes) {
        if(node.xScale > 3) {
            node.xScale = 3;
            node.yScale = 3;
        }else if(node.xScale <0.5) {
            node.xScale  = 0.51;
            node.yScale  = 0.51;
        }else{
            SKAction *scale = [SKAction scaleBy:recognizer.scale duration:0];
            [node runAction:scale];
        }
    }
    recognizer.scale = 1;

}
/*!
 * @discussion Méthode qui convertit un angle  degré -> redian.
 * @param degree l'angle en degré
 * @return l'angle en radian.
 */
float degreeToRadion(float degree) {
    return degree / 180.0f * M_PI;
}


@end
