//
//  ViewEditorController.h
//  Projet3_Chat
//
//  Created by Wael Bayoudh on 16-02-18.
//  Copyright © 2016 Wael Bayoudh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SpriteKit/SpriteKit.h>

@interface ViewEditorController : UIViewController
- (IBAction)menuDisplayAction:(id)sender;
@property (weak, nonatomic) IBOutlet UIView *slideMenu;
//@property (weak, nonatomic) IBOutlet UILabel *image;
//- (IBAction)minusScale:(id)sender;

//- (IBAction)plusScale:(id)sender;

@end
