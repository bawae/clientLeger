//
//  main.m
//  clientLeger
//
//  Created by Wael Bayoudh on 16-03-05.
//  Copyright © 2016 Wael Bayoudh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
