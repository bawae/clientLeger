//
//  ViewMenuController.h
//  Projet3_Chat
//
//  Created by Wael Bayoudh on 16-02-18.
//  Copyright © 2016 Wael Bayoudh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewMenuController : UIViewController
{
    int countInt;
    NSTimer *timer;
    
}
@property (weak, nonatomic) IBOutlet UIButton *cardsButton;
@property (weak, nonatomic) IBOutlet UIImageView *profileImage;
@property (strong, nonatomic) IBOutlet UIView *usernameDisplayLabel;
@property (nonatomic, retain) NSInputStream *inputStream;
@property (nonatomic, retain) NSOutputStream *outputStream;
@property  BOOL isGuest;

@end
